<?php
/**
 * Plugin Name: ACHplug — Take bank payments, no card processor
 * Plugin URI:  https://achplug.com
 * Description: Bank payments for businesses and nonprofits — one-time or recurring. Your customer approves on your site; your own bank collects. No processor, no percentage. Sales Journal included.
 * Version:     2.0.0
 * Author:      Jersey Shore Constllc
 * Author URI:  https://achplug.com
 * License:     GPLv2 or later
 * Text Domain: achplug
 *
 * ACHplug 2.0.0 (build 2h, 3 Sep 2026) — comparison row: several businesses under one login
 * Shortcode:  [achplug name="Roof inspection deposit" price="475" desc="Holds your date." sku="DEP"]
 * Block:      "ACHplug — pay from your bank" in the editor.
 * Admin:      ACHplug → Dashboard / Collect / Sales Journal / Settings / Getting started / Features
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ACHPLUG_VER', '2.0.0' );
define( 'ACHPLUG_DIR', plugin_dir_path( __FILE__ ) );
define( 'ACHPLUG_URL', plugin_dir_url( __FILE__ ) );

/* ==================================================================
 * Settings
 * ================================================================*/
function achplug_defaults() {
	return array(
		'entity' => '', 'address' => '', 'bank' => '', 'routing' => '', 'account' => '',
		'discount' => '5', 'prefix' => strtoupper( substr( preg_replace( '/[^a-z0-9]/i', '', get_bloginfo( 'name' ) ), 0, 2 ) ),
		'email' => get_option( 'admin_email' ), 'phone' => '',
		'days' => 'often within minutes, up to 3 business days',
		'explain' => "You send the money straight from your bank account, the same way you pay a utility bill. No card company sits in the middle taking a cut. Most banks now send it instantly; a few take up to three business days.",
		'mode' => 'sale', 'ein' => '', 'amounts' => '25,50,100,250',
		'collect' => 'pull', 'company_id' => '', 'odfi_routing' => '', 'recurring' => '0',
		'card_url' => '', 'card_label' => 'Pay by card', 'card_note' => 'Instant. Visa, Mastercard, Amex.',
		'ack_tpl' => '', 'receipt_tpl' => '',
		'w_bank_label' => 'Pay from your bank', 'w_bank_button' => 'Pay from my bank', 'w_save' => 'You save',
		'w_buy' => 'Buy', 'w_thanks' => 'Thank you.',
	);
}
function achplug_opt( $k ) {
	static $o = null;
	if ( $o === null ) $o = wp_parse_args( (array) get_option( 'achplug_settings', array() ), achplug_defaults() );
	return isset( $o[ $k ] ) ? $o[ $k ] : '';
}
function achplug_money( $n ) { return '$' . number_format( (float) $n, 2 ); }
function achplug_ready() {
	if ( achplug_opt( 'collect' ) === 'push' ) return achplug_opt( 'routing' ) && achplug_opt( 'account' ) && achplug_opt( 'entity' );
	return (bool) achplug_opt( 'entity' );
}
function achplug_collect_setup() { return achplug_opt( 'company_id' ) && achplug_opt( 'odfi_routing' ); }

add_action( 'admin_init', function () {
	register_setting( 'achplug', 'achplug_settings', array(
		'sanitize_callback' => function ( $in ) {
			$out = array();
			foreach ( achplug_defaults() as $k => $d ) {
				$v = isset( $in[ $k ] ) ? $in[ $k ] : ( in_array( $k, array( 'recurring' ), true ) ? '0' : $d );
				$out[ $k ] = in_array( $k, array( 'explain', 'ack_tpl', 'receipt_tpl' ), true ) ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
			}
			$out['discount'] = max( 0, min( 90, (float) $out['discount'] ) );
			$out['card_url'] = esc_url_raw( $out['card_url'] );
			$out['mode'] = $out['mode'] === 'donation' ? 'donation' : 'sale';
			$out['collect'] = $out['collect'] === 'push' ? 'push' : 'pull';
			$out['recurring'] = ! empty( $in['recurring'] ) ? '1' : '0';
			$out['routing'] = preg_replace( '/\D/', '', $out['routing'] );
			$out['odfi_routing'] = preg_replace( '/\D/', '', $out['odfi_routing'] );
			if ( $out['routing'] ) {
				$lk = achplug_bank_lookup( $out['routing'] );
				if ( ! $lk['ok'] ) { add_settings_error( 'achplug', 'routing', 'That routing number ' . $lk['reason'] . '. Not saved — it is nine digits, bottom left of your checks.' ); $old = (array) get_option( 'achplug_settings', array() ); $out['routing'] = isset( $old['routing'] ) ? $old['routing'] : ''; }
				elseif ( $lk['name'] ) { $out['bank'] = $lk['name']; add_settings_error( 'achplug', 'routing_ok', 'Routing number verified: ' . $lk['name'] . ( $lk['city'] ? ', ' . $lk['city'] : '' ) . ' ' . $lk['state'], 'success' ); }
			}
			foreach ( array( 'ack_tpl' => achplug_def_ack(), 'receipt_tpl' => $out['mode'] === 'donation' ? achplug_def_receipt_don() : achplug_def_receipt() ) as $k => $def ) if ( trim( $out[ $k ] ) === trim( $def ) ) $out[ $k ] = '';
			return $out;
		},
	) );
} );

/* ==================================================================
 * Bank lookup: ABA check digit, then the Federal Reserve directory at achplug.com
 * ================================================================*/
function achplug_aba_ok( $r ) {
	if ( ! preg_match( '/^\d{9}$/', $r ) || preg_match( '/^(\d)\1{8}$/', $r ) ) return false;
	$p = (int) substr( $r, 0, 2 );
	if ( ! ( ( $p >= 0 && $p <= 12 ) || ( $p >= 21 && $p <= 32 ) || ( $p >= 61 && $p <= 72 ) || $p === 80 ) ) return false;
	$d = array_map( 'intval', str_split( $r ) );
	return ( 3 * ( $d[0] + $d[3] + $d[6] ) + 7 * ( $d[1] + $d[4] + $d[7] ) + ( $d[2] + $d[5] + $d[8] ) ) % 10 === 0;
}
function achplug_bank_lookup( $rn ) {
	if ( ! achplug_aba_ok( $rn ) ) return array( 'ok' => false, 'name' => '', 'reason' => 'fails the bank check digit or is outside the Federal Reserve ranges' );
	$c = get_transient( 'achplug_bank_' . $rn ); if ( is_array( $c ) ) return $c;
	$res = wp_remote_get( 'https://achplug.com/api/bank?rn=' . $rn, array( 'timeout' => 6 ) );
	$out = array( 'ok' => true, 'name' => '', 'city' => '', 'state' => '', 'reason' => '' );
	if ( ! is_wp_error( $res ) && wp_remote_retrieve_response_code( $res ) === 200 ) {
		$j = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( is_array( $j ) ) {
			if ( ! empty( $j['name'] ) ) $out = array( 'ok' => true, 'name' => $j['name'], 'city' => isset( $j['city'] ) ? $j['city'] : '', 'state' => isset( $j['state'] ) ? $j['state'] : '', 'reason' => '' );
			elseif ( isset( $j['ok'] ) && $j['ok'] === false ) $out = array( 'ok' => false, 'name' => '', 'city' => '', 'state' => '', 'reason' => 'is not in the Federal Reserve ACH directory' );
		}
	}
	set_transient( 'achplug_bank_' . $rn, $out, DAY_IN_SECONDS );
	return $out;
}

/* ==================================================================
 * Encryption for customers' account numbers — AES-256-GCM, key kept in this site only
 * ================================================================*/
function achplug_key() {
	$k = get_option( 'achplug_enc_key' );
	if ( ! $k ) { $k = bin2hex( random_bytes( 32 ) ); add_option( 'achplug_enc_key', $k, '', 'no' ); }
	return hash( 'sha256', 'achplug:' . $k, true );
}
function achplug_encrypt( $text ) {
	$iv = random_bytes( 12 ); $tag = '';
	$ct = openssl_encrypt( $text, 'aes-256-gcm', achplug_key(), OPENSSL_RAW_DATA, $iv, $tag );
	return base64_encode( $iv . $tag . $ct );
}
function achplug_decrypt( $b64 ) {
	$raw = base64_decode( $b64 ); if ( strlen( $raw ) < 29 ) return '';
	$pt = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', achplug_key(), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
	return $pt === false ? '' : $pt;
}

/* ==================================================================
 * Emails
 * ================================================================*/
function achplug_def_ack() { return "Thank you, {name}.\n\nYou have authorized a payment to {entity}{address_line} in the amount of {amount} from your {acct_type} account at {bank}, ending {last4}.{repeat_line}\nReference: {ref}\n\nYou will receive a receipt when the funds clear — usually quick, but it can take 1 to 3 business days.\n\nYour authorization, for your records:\n{agreed}\n\n{revoke_line}"; }
function achplug_def_receipt() { return "Thank you from {entity}.\n\nReceived {amount} on {date}.\nReference: {ref}\nFor: {product}\n{link}\n\n{site}"; }
function achplug_def_receipt_don() { return "Thank you from {entity}.\n\nYour donation of {amount} was received on {date}. Reference: {ref}.\nOur tax ID (EIN) is {ein}. No goods or services were provided in exchange for this contribution. Please keep this email as your donation receipt.\n\n{site}"; }
function achplug_fill( $t, $v ) { return preg_replace_callback( '/\{(\w+)\}/', fn( $m ) => array_key_exists( $m[1], $v ) ? $v[ $m[1] ] : $m[0], $t ); }
function achplug_vars( $id, $extra = array() ) {
	$m = fn( $k ) => get_post_meta( $id, $k, true );
	$repeat = $m( 'interval' );
	$v = array(
		'name' => $m( 'name' ), 'product' => $m( 'product' ), 'ref' => get_the_title( $id ), 'amount' => achplug_money( $m( 'amount' ) ),
		'date' => substr( (string) ( $m( 'paid_at' ) ?: current_time( 'mysql' ) ), 0, 10 ), 'entity' => achplug_opt( 'entity' ), 'ein' => achplug_opt( 'ein' ),
		'address_line' => achplug_opt( 'address' ) ? ', ' . achplug_opt( 'address' ) : '', 'bank' => $m( 'bank_name' ), 'last4' => $m( 'last4' ), 'acct_type' => $m( 'acct_type' ) ?: 'checking',
		'repeat_line' => $repeat ? "\nThis repeats " . $repeat . ( $m( 'end_count' ) ? ' for ' . $m( 'end_count' ) . ' payments' : ( $m( 'end_date' ) ? ' until ' . $m( 'end_date' ) : ' until you stop it' ) ) . '.' : '',
		'agreed' => $m( 'agreed' ), 'link' => $m( 'link' ), 'site' => home_url(), 'days' => achplug_opt( 'days' ),
		'revoke_line' => $m( 'token' ) ? 'Manage or revoke this payment any time: ' . add_query_arg( array( 'achplug_manage' => $m( 'token' ) ), home_url( '/' ) ) : '',
	);
	return array_merge( $v, $extra );
}
function achplug_mail( $to, $subject, $body ) {
	if ( ! $to ) return;
	$h = array( 'Content-Type: text/plain; charset=UTF-8' );
	if ( achplug_opt( 'email' ) ) $h[] = 'Reply-To: ' . achplug_opt( 'email' );
	wp_mail( $to, $subject, $body, $h );
}

/* ==================================================================
 * Orders — private post type. status: awaiting (push) | authorized | collecting | paid | cancelled | revoked
 * ================================================================*/
add_action( 'init', function () {
	register_post_type( 'achplug_order', array( 'labels' => array( 'name' => 'ACH orders' ), 'public' => false, 'show_ui' => false, 'supports' => array( 'title' ) ) );
	wp_register_script( 'achplug-block', ACHPLUG_URL . 'assets/block.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor' ), ACHPLUG_VER, true );
	register_block_type( 'achplug/box', array(
		'editor_script' => 'achplug-block',
		'attributes' => array( 'name' => array( 'type' => 'string', 'default' => 'What you sell' ), 'price' => array( 'type' => 'string', 'default' => '20' ), 'desc' => array( 'type' => 'string', 'default' => '' ), 'sku' => array( 'type' => 'string', 'default' => '' ) ),
		'render_callback' => fn( $a ) => do_shortcode( sprintf( '[achplug name="%s" price="%s" desc="%s" sku="%s"]', esc_attr( $a['name'] ), esc_attr( $a['price'] ), esc_attr( $a['desc'] ), esc_attr( $a['sku'] ) ) ),
	) );
	if ( ! wp_next_scheduled( 'achplug_daily' ) ) wp_schedule_event( strtotime( 'tomorrow 13:00 UTC' ), 'daily', 'achplug_daily' );
} );
register_deactivation_hook( __FILE__, fn() => wp_clear_scheduled_hook( 'achplug_daily' ) );
register_activation_hook( __FILE__, function () { add_option( 'achplug_go_start', 1 ); achplug_key(); } );
add_action( 'admin_init', function () { if ( get_option( 'achplug_go_start' ) && ! wp_doing_ajax() && current_user_can( 'manage_options' ) ) { delete_option( 'achplug_go_start' ); wp_safe_redirect( admin_url( 'admin.php?page=achplug-start' ) ); exit; } } );

function achplug_orders( $status, $n = 200 ) {
	$q = array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'numberposts' => $n, 'orderby' => 'date', 'order' => 'DESC' );
	if ( $status ) $q['meta_query'] = array( array( 'key' => 'status', 'value' => (array) $status, 'compare' => 'IN' ) );
	return get_posts( $q );
}
function achplug_ref() { return achplug_opt( 'prefix' ) . '-' . str_pad( wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT ); }
function achplug_next_due( $from, $interval ) {
	$d = new DateTime( $from );
	if ( $interval === 'weekly' ) { $d->modify( '+1 week' ); return $d->format( 'Y-m-d' ); }
	$day = (int) $d->format( 'j' ); $d->modify( 'first day of ' . ( $interval === 'yearly' ? '+1 year' : '+1 month' ) );
	$d->setDate( (int) $d->format( 'Y' ), (int) $d->format( 'n' ), min( $day, (int) $d->format( 't' ) ) ); // the 31st becomes the 28th in February, not March 3rd
	return $d->format( 'Y-m-d' );
}

/* ==================================================================
 * Front: assets + shortcode
 * ================================================================*/
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'achplug', ACHPLUG_URL . 'assets/achplug.css', array(), ACHPLUG_VER );
	wp_register_script( 'achplug', ACHPLUG_URL . 'assets/achplug.js', array(), ACHPLUG_VER, true );
	wp_localize_script( 'achplug', 'ACHPLUG', array( 'rest' => esc_url_raw( rest_url( 'achplug/v1/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
} );

add_shortcode( 'achplug', function ( $a ) {
	$a = shortcode_atts( array( 'name' => '', 'price' => '0', 'desc' => '', 'sku' => '', 'card' => '', 'repeat' => '' ), $a, 'achplug' );
	if ( ! achplug_ready() ) return current_user_can( 'manage_options' ) ? '<p><em>ACHplug: finish ACHplug → Settings (payee name at least) and this box will appear.</em></p>' : '';
	wp_enqueue_style( 'achplug' ); wp_enqueue_script( 'achplug' );
	$don = achplug_opt( 'mode' ) === 'donation'; $pull = achplug_opt( 'collect' ) !== 'push';
	$price = (float) $a['price']; $disc = $don ? 0 : (float) achplug_opt( 'discount' ); $ach = round( $price * ( 1 - $disc / 100 ), 2 );
	$card = $don ? '' : ( $a['card'] ? $a['card'] : achplug_opt( 'card_url' ) );
	$rec = ! $don && achplug_opt( 'recurring' ) === '1' && $a['repeat'] !== 'off';
	$cfg = array( 'name' => $a['name'], 'desc' => $a['desc'], 'sku' => $a['sku'], 'price' => $price, 'ach' => $ach, 'disc' => $disc, 'card' => $card, 'don' => $don, 'pull' => $pull, 'rec' => $rec,
		'amounts' => $don && ! $price ? array_values( array_filter( array_map( 'floatval', explode( ',', achplug_opt( 'amounts' ) ) ) ) ) : array(),
		'entity' => achplug_opt( 'entity' ), 'bank' => achplug_opt( 'bank' ), 'routing' => $pull ? '' : achplug_opt( 'routing' ), 'account' => $pull ? '' : achplug_opt( 'account' ),
		'days' => achplug_opt( 'days' ), 'explain' => achplug_opt( 'explain' ), 'contact' => trim( achplug_opt( 'email' ) . ( achplug_opt( 'phone' ) ? ' · ' . achplug_opt( 'phone' ) : '' ) ),
		'w' => array( 'bank_label' => achplug_opt( 'w_bank_label' ), 'bank_button' => achplug_opt( 'w_bank_button' ), 'save' => achplug_opt( 'w_save' ), 'buy' => achplug_opt( 'w_buy' ), 'thanks' => achplug_opt( 'w_thanks' ), 'card_label' => achplug_opt( 'card_label' ), 'card_note' => achplug_opt( 'card_note' ) ) );
	return '<div class="achplug" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"></div>';
} );

/* ==================================================================
 * REST
 * ================================================================*/
add_action( 'rest_api_init', function () {
	$nonce_ok = fn( WP_REST_Request $r ) => (bool) wp_verify_nonce( $r->get_header( 'x-wp-nonce' ), 'wp_rest' );
	register_rest_route( 'achplug/v1', '/bank', array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function ( WP_REST_Request $r ) {
		$lk = achplug_bank_lookup( preg_replace( '/\D/', '', (string) $r['rn'] ) );
		return array( 'ok' => $lk['ok'], 'name' => $lk['name'], 'city' => isset( $lk['city'] ) ? $lk['city'] : '', 'state' => isset( $lk['state'] ) ? $lk['state'] : '' );
	} ) );
	// PULL: the customer authorizes
	register_rest_route( 'achplug/v1', '/authorize', array( 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function ( WP_REST_Request $r ) use ( $nonce_ok ) {
		if ( ! $nonce_ok( $r ) ) return new WP_Error( 'nonce', 'Please reload the page and try again.', array( 'status' => 403 ) );
		$name = sanitize_text_field( $r['name'] ); $email = sanitize_email( $r['email'] ); $product = sanitize_text_field( $r['product'] ); $sku = sanitize_text_field( $r['sku'] );
		$amount = round( (float) $r['amount'], 2 ); $routing = preg_replace( '/\D/', '', (string) $r['routing'] ); $account = preg_replace( '/[^0-9A-Za-z-]/', '', (string) $r['account'] );
		$type = $r['acct_type'] === 'savings' ? 'savings' : 'checking';
		if ( ! $name || ! is_email( $email ) || ! $product || $amount <= 0 ) return new WP_Error( 'missing', 'Please give your name and a working email address.', array( 'status' => 400 ) );
		if ( empty( $r['agree'] ) ) return new WP_Error( 'agree', 'Please check the box to authorize the payment.', array( 'status' => 400 ) );
		$lk = achplug_bank_lookup( $routing ); if ( ! $lk['ok'] ) return new WP_Error( 'routing', 'That routing number ' . $lk['reason'] . '.', array( 'status' => 400 ) );
		if ( strlen( $account ) < 4 || strlen( $account ) > 17 || preg_match( '/^(\d)\1+$/', $account ) ) return new WP_Error( 'account', 'That account number does not look right.', array( 'status' => 400 ) );
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : ''; $key = 'achplug_ip_' . md5( $ip ); $n = (int) get_transient( $key );
		if ( $n >= 5 ) return new WP_Error( 'slow', 'Too many attempts from this connection. Try again in an hour.', array( 'status' => 429 ) ); set_transient( $key, $n + 1, HOUR_IN_SECONDS );
		$repeat = in_array( $r['repeat'], array( 'weekly', 'monthly', 'yearly' ), true ) && achplug_opt( 'recurring' ) === '1' ? $r['repeat'] : '';
		$end_count = $repeat && (int) $r['end_count'] > 0 ? min( 999, (int) $r['end_count'] ) : ''; $end_date = $repeat && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $r['end_date'] ) ? $r['end_date'] : '';
		$bank = $lk['name'] ?: 'your bank'; $last4 = substr( $account, -4 ); $ref = achplug_ref(); $token = wp_generate_password( 24, false );
		$agreed = sprintf( 'I authorize %s to debit my %s account at %s (routing %s, account ending %s) for %s%s. I can revoke this any time from the link in my email. %s from %s.', achplug_opt( 'entity' ), $type, $bank, $routing, $last4, achplug_money( $amount ), $repeat ? ' ' . $repeat . ( $end_count ? ' for ' . $end_count . ' payments' : ( $end_date ? ' until ' . $end_date : ' until I cancel' ) ) : '', current_time( 'Y-m-d' ), $ip );
		$id = wp_insert_post( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'post_title' => $ref, 'meta_input' => array(
			'name' => $name, 'email' => $email, 'product' => $product, 'sku' => $sku, 'amount' => $amount, 'status' => 'authorized', 'ip' => $ip,
			'routing' => $routing, 'bank_name' => $bank, 'last4' => $last4, 'acct_type' => $type, 'enc' => achplug_encrypt( wp_json_encode( array( 'routing' => $routing, 'account' => $account ) ) ),
			'agreed' => $agreed, 'token' => $token, 'interval' => $repeat, 'end_count' => $end_count, 'end_date' => $end_date, 'done' => 1, 'next_due' => $repeat ? achplug_next_due( current_time( 'Y-m-d' ), $repeat ) : '', 'plan_status' => $repeat ? 'active' : '', 'parent_auth' => 0,
		) ) );
		if ( ! $id ) return new WP_Error( 'save', 'Could not save. Try again.', array( 'status' => 500 ) );
		$v = achplug_vars( $id );
		achplug_mail( achplug_opt( 'email' ), "Payment authorized $ref — " . achplug_money( $amount ), "$name <$email> authorized " . achplug_money( $amount ) . " for $product from $bank (account ending $last4).\n" . ( $repeat ? "Repeats $repeat.\n" : '' ) . "\nReady to collect: " . admin_url( 'admin.php?page=achplug-collect' ) );
		achplug_mail( $email, ( achplug_opt( 'mode' ) === 'donation' ? 'Your donation to ' : 'Your payment to ' ) . achplug_opt( 'entity' ) . " — $ref", achplug_fill( achplug_opt( 'ack_tpl' ) ?: achplug_def_ack(), $v ) );
		$notice = achplug_fill( "Thank you for your " . ( achplug_opt( 'mode' ) === 'donation' ? 'donation' : 'purchase' ) . ".\n\nYou have authorized a payment to {entity}{address_line} in the amount of {amount} from your {acct_type} account at {bank}, ending {last4}.{repeat_line}\nReference: {ref}\n\nYou will receive a receipt when the funds clear — usually quick, but it can take 1 to 3 business days.", $v );
		return array( 'ref' => $ref, 'notice' => $notice );
	} ) );
	// PUSH (kept): the customer says "I've sent it"
	register_rest_route( 'achplug/v1', '/order', array( 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function ( WP_REST_Request $r ) use ( $nonce_ok ) {
		if ( ! $nonce_ok( $r ) ) return new WP_Error( 'nonce', 'Please reload the page and try again.', array( 'status' => 403 ) );
		$name = sanitize_text_field( $r['name'] ); $email = sanitize_email( $r['email'] ); $product = sanitize_text_field( $r['product'] ); $amount = round( (float) $r['amount'], 2 );
		if ( ! $name || ! is_email( $email ) || ! $product || $amount <= 0 ) return new WP_Error( 'missing', 'Please give your name and a working email address.', array( 'status' => 400 ) );
		$ref = achplug_ref();
		$id = wp_insert_post( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'post_title' => $ref, 'meta_input' => array( 'name' => $name, 'email' => $email, 'product' => $product, 'sku' => sanitize_text_field( $r['sku'] ), 'amount' => $amount, 'status' => 'awaiting' ) ) );
		achplug_mail( achplug_opt( 'email' ), "ACH order $ref — " . achplug_money( $amount ), "$name <$email> says a transfer of " . achplug_money( $amount ) . " is on its way.\nProduct: $product\nReference: $ref\n\n" . admin_url( 'admin.php?page=achplug' ) );
		achplug_mail( $email, 'Your order from ' . achplug_opt( 'entity' ) . " — $ref", "Thank you, $name.\n\nWe are watching for your transfer of " . achplug_money( $amount ) . ".\nReference (put this in the memo): $ref\nPay to: " . achplug_opt( 'entity' ) . "\nRouting: " . achplug_opt( 'routing' ) . "   Account: " . achplug_opt( 'account' ) . "\n\nWhen it lands — " . achplug_opt( 'days' ) . " — you will get a receipt at this address." );
		return array( 'ref' => $ref );
	} ) );
} );

/* ==================================================================
 * Customer's manage/revoke page  — ?achplug_manage=TOKEN on the site's home
 * ================================================================*/
add_action( 'template_redirect', function () {
	if ( empty( $_GET['achplug_manage'] ) ) return;
	$tok = sanitize_text_field( $_GET['achplug_manage'] );
	$p = get_posts( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'numberposts' => 1, 'meta_key' => 'token', 'meta_value' => $tok ) );
	if ( ! $p ) { status_header( 404 ); wp_die( 'That link does not work.', 'ACHplug', array( 'response' => 404 ) ); }
	$o = $p[0]; $id = $o->ID; $m = fn( $k ) => get_post_meta( $id, $k, true );
	if ( isset( $_POST['achplug_revoke'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'achplug_revoke_' . $tok ) ) {
		update_post_meta( $id, 'plan_status', 'revoked' ); update_post_meta( $id, 'enc', '' );
		if ( $m( 'status' ) === 'authorized' ) update_post_meta( $id, 'status', 'revoked' );
		foreach ( get_posts( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'numberposts' => -1, 'meta_key' => 'parent_auth', 'meta_value' => $id ) ) as $c ) if ( get_post_meta( $c->ID, 'status', true ) === 'authorized' ) update_post_meta( $c->ID, 'status', 'revoked' );
		achplug_mail( achplug_opt( 'email' ), $m( 'name' ) . ' revoked authorization ' . $o->post_title, $m( 'name' ) . ' <' . $m( 'email' ) . '> revoked ' . $o->post_title . '. Anything not yet sent to the bank is cancelled.' );
		$msg = '<p style="background:#eef5f1;border:1px solid #9cc7b1;border-radius:8px;padding:10px 14px"><b>Revoked.</b> Nothing further will be collected.</p>';
	} else $msg = '';
	$st = $m( 'plan_status' ) ?: $m( 'status' );
	$children = get_posts( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'numberposts' => 50, 'meta_key' => 'parent_auth', 'meta_value' => $id ) );
	status_header( 200 ); nocache_headers();
	echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Your payment — ' . esc_html( achplug_opt( 'entity' ) ) . '</title><style>body{font:16px/1.5 system-ui,sans-serif;color:#17251F;background:#F7F9F6;margin:0;padding:20px}.w{max-width:640px;margin:0 auto}.c{background:#fff;border:1px solid #C9D4CE;border-radius:10px;padding:16px 18px}h1{font-family:Georgia,serif;font-weight:600;font-size:26px}table{width:100%;border-collapse:collapse;font-size:14px;margin-top:10px}td,th{padding:6px 8px;border-bottom:1px solid #C9D4CE;text-align:left}button{font:inherit;font-weight:600;border:0;border-radius:7px;padding:10px 16px;background:#b91c1c;color:#fff;cursor:pointer}small{color:#5F6F68}</style></head><body><div class="w">';
	echo '<h1>Your payment to ' . esc_html( achplug_opt( 'entity' ) ) . '</h1>' . $msg . '<div class="c"><p><b>' . esc_html( achplug_money( $m( 'amount' ) ) ) . ( $m( 'interval' ) ? ' ' . esc_html( $m( 'interval' ) ) : '' ) . '</b> for ' . esc_html( $m( 'product' ) ) . ' · from ' . esc_html( $m( 'bank_name' ) ) . ' ····' . esc_html( $m( 'last4' ) ) . '</p><p>Status: <b>' . esc_html( ucfirst( $st ) ) . '</b>' . ( $m( 'interval' ) && $st === 'active' ? ' · next: ' . esc_html( $m( 'next_due' ) ) . ( $m( 'end_count' ) ? ' · ' . esc_html( $m( 'done' ) ) . ' of ' . esc_html( $m( 'end_count' ) ) : '' ) : '' ) . '</p>';
	echo '<p><small>You are in control. This page revokes the authorization you gave; anything not yet sent to the bank is cancelled and nothing further is collected. Your account number is deleted when you revoke.</small></p>';
	if ( in_array( $st, array( 'active', 'authorized', 'collecting', 'paid' ), true ) && $m( 'enc' ) ) echo '<form method="post">' . wp_nonce_field( 'achplug_revoke_' . $tok, '_wpnonce', true, false ) . '<button name="achplug_revoke" value="1">Revoke this authorization</button></form>';
	echo '</div>';
	if ( $children ) { echo '<table><tr><th>Reference</th><th>Date</th><th>Amount</th><th>Status</th></tr>'; foreach ( $children as $c ) echo '<tr><td>' . esc_html( $c->post_title ) . '</td><td>' . esc_html( get_date_from_gmt( $c->post_date_gmt, 'Y-m-d' ) ) . '</td><td>' . esc_html( achplug_money( get_post_meta( $c->ID, 'amount', true ) ) ) . '</td><td>' . esc_html( get_post_meta( $c->ID, 'status', true ) ) . '</td></tr>'; echo '</table>'; }
	echo '<p><small>Questions: ' . esc_html( achplug_opt( 'email' ) ) . ( achplug_opt( 'phone' ) ? ' · ' . esc_html( achplug_opt( 'phone' ) ) : '' ) . '</small></p></div></body></html>';
	exit;
} );

/* ==================================================================
 * Daily: repeating debits become new authorized orders; seller gets the collection email
 * ================================================================*/
add_action( 'achplug_daily', function () {
	$today = current_time( 'Y-m-d' );
	foreach ( achplug_orders( array( 'authorized', 'collecting', 'paid' ), -1 ) as $o ) {
		$id = $o->ID; if ( get_post_meta( $id, 'plan_status', true ) !== 'active' ) continue;
		$interval = get_post_meta( $id, 'interval', true ); $due = get_post_meta( $id, 'next_due', true ); if ( ! $interval || ! $due || $due > $today ) continue;
		$ref = $o->post_title . '-' . substr( str_replace( '-', '', $due ), 2 );
		$m = fn( $k ) => get_post_meta( $id, $k, true );
		wp_insert_post( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'post_title' => $ref, 'meta_input' => array( 'name' => $m( 'name' ), 'email' => $m( 'email' ), 'product' => $m( 'product' ), 'sku' => $m( 'sku' ), 'amount' => $m( 'amount' ), 'status' => 'authorized', 'bank_name' => $m( 'bank_name' ), 'last4' => $m( 'last4' ), 'acct_type' => $m( 'acct_type' ), 'enc' => $m( 'enc' ), 'parent_auth' => $id ) ) );
		$done = (int) $m( 'done' ) + 1; $nd = achplug_next_due( $due, $interval );
		$finished = ( $m( 'end_count' ) && $done >= (int) $m( 'end_count' ) ) || ( $m( 'end_date' ) && $nd > $m( 'end_date' ) );
		update_post_meta( $id, 'done', $done ); update_post_meta( $id, 'next_due', $nd ); if ( $finished ) update_post_meta( $id, 'plan_status', 'finished' );
		achplug_mail( $m( 'email' ), 'Coming up: ' . achplug_money( $m( 'amount' ) ) . ' to ' . achplug_opt( 'entity' ), 'Your ' . $interval . ' payment of ' . achplug_money( $m( 'amount' ) ) . ' to ' . achplug_opt( 'entity' ) . ' for ' . $m( 'product' ) . ' is being collected from your ' . $m( 'bank_name' ) . ' account ending ' . $m( 'last4' ) . ", as you authorized.\nReference: $ref\n\nPause or stop any time: " . add_query_arg( array( 'achplug_manage' => $m( 'token' ) ), home_url( '/' ) ) );
	}
	$ready = achplug_orders( 'authorized', -1 );
	if ( $ready && achplug_opt( 'collect' ) !== 'push' ) {
		$t = array_sum( array_map( fn( $o ) => (float) get_post_meta( $o->ID, 'amount', true ), $ready ) );
		achplug_mail( achplug_opt( 'email' ), "Today's collection: " . count( $ready ) . ' payment' . ( count( $ready ) > 1 ? 's' : '' ) . ', ' . achplug_money( $t ), achplug_collect_setup()
			? "Your bank file for today is ready.\n\n1. Open Collect: " . admin_url( 'admin.php?page=achplug-collect' ) . "\n2. Press Download bank file and upload it on your bank's ACH origination page.\n3. Press \"I uploaded it\" so ACHplug knows it went.\n\nWhen the money shows in your account, press Received on each one — that sends the customer's receipt."
			: count( $ready ) . " customer payment(s) are authorized and waiting. To collect them, enter your Company ID and origination routing number in ACHplug → Settings → 6. Collecting.\n\nHow to set this up with your bank: https://achplug.com/help-collect.html" );
	}
} );

/* ==================================================================
 * Admin: header, menus, pages
 * ================================================================*/
function achplug_head( $title, $sub = '' ) {
	$cur = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
	$nav = array( 'achplug' => 'Dashboard', 'achplug-collect' => 'Collect', 'achplug-journal' => 'Sales Journal', 'achplug-settings' => 'Settings', 'achplug-start' => 'Getting started', 'achplug-features' => 'Features' );
	echo '<style>.achplug-wrap{max-width:1140px}.achplug-bar{display:flex;align-items:center;gap:18px;flex-wrap:wrap;background:#fff;border:1px solid #ccd;border-radius:10px;padding:12px 18px;margin:16px 0 18px}.achplug-logo{font-family:Georgia,serif;font-size:22px;font-weight:600;color:#17251F;text-decoration:none;display:inline-flex;align-items:center;gap:8px}.achplug-logo b{color:#1E6B4E}.achplug-nav{display:flex;gap:6px;flex-wrap:wrap;margin-left:auto}.achplug-nav a{text-decoration:none;color:#17251F;border:1px solid #ccd;border-radius:20px;padding:6px 13px;font-size:13px;background:#F7F9F6}.achplug-nav a.current{background:#1E6B4E;color:#fff;border-color:#1E6B4E}.achplug-nav a.feat{border-color:#1E6B4E;color:#1E6B4E;font-weight:600}.achplug-wrap h1,.achplug-wrap h2,.achplug-wrap h3{font-family:Georgia,serif;font-weight:600}.achplug-wrap h2{margin-top:26px}.achplug-card{background:#fff;border:1px solid #ccd;border-radius:10px;padding:16px 18px;max-width:960px}.achplug-cards{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}.achplug-cards div{background:#fff;border:1px solid #ccd;border-radius:8px;padding:12px 16px;min-width:170px}.achplug-cards b{display:block;font-size:24px}.achplug-cards small{color:#666}.achplug-tab{display:inline-block;padding:5px 12px;border:1px solid #ccd;border-radius:16px;margin-right:6px;text-decoration:none;background:#fff}.achplug-tab.current{background:#1d2327;color:#fff;border-color:#1d2327}.achplug-cta{display:inline-block;background:#1E6B4E;color:#fff;text-decoration:none;font-weight:600;padding:10px 18px;border-radius:8px}.achplug-cta:hover{color:#fff;background:#144A36}.achplug-notice{background:#fff8e6;border:1px solid #e8c77a;border-radius:8px;padding:10px 14px;margin:10px 0;max-width:960px}.achplug-notice.ok{background:#eef5f1;border-color:#9cc7b1}.achplug-tiles{display:grid;grid-template-columns:1fr 1fr;gap:10px;max-width:960px}.achplug-tile{display:block;border:1.5px solid #ccd;border-radius:10px;padding:12px 14px 12px 40px;position:relative;cursor:pointer;background:#fff}.achplug-tile input{position:absolute;left:14px;top:16px}.achplug-tile b{display:block;font-size:15px}.achplug-tile span{display:block;color:#5F6F68;font-size:13px;margin-top:2px}.achplug-tile:has(input:checked){border-color:#1E6B4E;background:#eef5f1}.achplug-wrap .form-table th{width:280px}.achplug-steps{counter-reset:s;list-style:none;margin:0;padding:0;max-width:820px}.achplug-steps li{counter-increment:s;background:#fff;border:1px solid #ccd;border-radius:8px;padding:14px 16px 14px 56px;position:relative;margin:10px 0;font-size:14px}.achplug-steps li::before{content:counter(s);position:absolute;left:14px;top:12px;width:28px;height:28px;border-radius:50%;background:#1E6B4E;color:#fff;font-weight:600;display:flex;align-items:center;justify-content:center}.achplug-steps b{display:block;margin-bottom:2px;font-size:15px}.achplug-cmp td:nth-child(2){background:#eef5f1;font-weight:600}.achplug-cmp th:nth-child(2){background:#1E6B4E;color:#fff}</style>';
	echo '<div class="wrap achplug-wrap"><div class="achplug-bar"><a class="achplug-logo" href="' . esc_url( admin_url( 'admin.php?page=achplug' ) ) . '"><svg viewBox="0 0 64 64" width="28" height="28" aria-hidden="true"><circle cx="32" cy="24" r="17" fill="#1E6B4E"/><circle cx="19" cy="30" r="10" fill="#1E6B4E"/><circle cx="45" cy="30" r="10" fill="#1E6B4E"/><path d="M29 38h6v14a3 3 0 0 1-6 0z" fill="#8a5a2b"/><path d="M22 56c4-3 16-3 20 0" fill="none" stroke="#8a5a2b" stroke-width="3" stroke-linecap="round"/><circle cx="40" cy="43" r="7.5" fill="#E8A33D"/><rect x="36.8" y="35" width="2.2" height="5" rx="1.1" fill="#F7F9F6"/><rect x="41" y="35" width="2.2" height="5" rx="1.1" fill="#F7F9F6"/><path d="M37 43.5l2 2 4-4" fill="none" stroke="#F7F9F6" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="24" cy="26" r="3" fill="#E8A33D"/><circle cx="33" cy="14" r="3" fill="#E8A33D"/></svg> ACH<b>plug</b></a><nav class="achplug-nav">';
	foreach ( $nav as $k => $l ) echo '<a class="' . ( $cur === $k ? 'current' : '' ) . ( $k === 'achplug-features' ? ' feat' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $k ) ) . '">' . $l . '</a>';
	echo '</nav></div><h1>' . esc_html( $title ) . '</h1>' . ( $sub ? '<p>' . $sub . '</p>' : '' );
}
add_action( 'admin_menu', function () {
	$n = count( achplug_orders( array( 'authorized', 'awaiting' ), 99 ) );
	$badge = $n ? " <span class='update-plugins count-$n'><span class='plugin-count'>$n</span></span>" : '';
	add_menu_page( 'ACHplug', 'ACHplug' . $badge, 'manage_options', 'achplug', 'achplug_dashboard_page', 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="24" r="17" fill="#a7aaad"/><circle cx="19" cy="30" r="10" fill="#a7aaad"/><circle cx="45" cy="30" r="10" fill="#a7aaad"/><path d="M29 38h6v14a3 3 0 0 1-6 0z" fill="#a7aaad"/><path d="M22 56c4-3 16-3 20 0" fill="none" stroke="#a7aaad" stroke-width="3" stroke-linecap="round"/><circle cx="40" cy="43" r="7.5" fill="#1d2327"/><rect x="36.8" y="35" width="2.2" height="5" rx="1.1" fill="#a7aaad"/><rect x="41" y="35" width="2.2" height="5" rx="1.1" fill="#a7aaad"/></svg>' ), 58 );
	add_submenu_page( 'achplug', 'Dashboard', 'Dashboard', 'manage_options', 'achplug', 'achplug_dashboard_page' );
	add_submenu_page( 'achplug', 'Collect', 'Collect', 'manage_options', 'achplug-collect', 'achplug_collect_page' );
	add_submenu_page( 'achplug', 'Sales Journal — ACH payments', 'Sales Journal', 'manage_options', 'achplug-journal', 'achplug_journal_page' );
	add_submenu_page( 'achplug', 'Settings', 'Settings', 'manage_options', 'achplug-settings', 'achplug_settings_page' );
	add_submenu_page( 'achplug', 'Getting started', 'Getting started', 'manage_options', 'achplug-start', 'achplug_start_page' );
	add_submenu_page( 'achplug', 'Features and comparison', 'Features', 'manage_options', 'achplug-features', 'achplug_features_page' );
} );

/* ---- actions: mark, collect, file ---- */
add_action( 'admin_post_achplug_mark', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'achplug_mark' ) ) wp_die( 'No.' );
	$id = (int) $_POST['id']; $to = sanitize_key( $_POST['to'] );
	if ( get_post_type( $id ) === 'achplug_order' && in_array( $to, array( 'paid', 'awaiting', 'cancelled', 'authorized' ), true ) ) {
		update_post_meta( $id, 'status', $to );
		if ( $to === 'paid' ) {
			update_post_meta( $id, 'paid_at', current_time( 'mysql' ) );
			$link = isset( $_POST['link'] ) ? esc_url_raw( $_POST['link'] ) : ''; if ( $link ) update_post_meta( $id, 'link', $link );
			$don = achplug_opt( 'mode' ) === 'donation';
			achplug_mail( get_post_meta( $id, 'email', true ), ( $don ? 'Your donation receipt — ' : 'Your receipt — ' ) . achplug_opt( 'entity' ) . ' — ' . get_the_title( $id ), achplug_fill( achplug_opt( 'receipt_tpl' ) ?: ( $don ? achplug_def_receipt_don() : achplug_def_receipt() ), achplug_vars( $id ) ) );
		}
		if ( $to === 'cancelled' && get_post_meta( $id, 'bank_name', true ) ) achplug_mail( get_post_meta( $id, 'email', true ), 'Your payment to ' . achplug_opt( 'entity' ) . ' did not go through — ' . get_the_title( $id ), 'Your bank returned the payment of ' . achplug_money( get_post_meta( $id, 'amount', true ) ) . ' for ' . get_post_meta( $id, 'product', true ) . ' (reference ' . get_the_title( $id ) . '). It is still owed. Please contact us: ' . achplug_opt( 'email' ) . ( achplug_opt( 'phone' ) ? ' · ' . achplug_opt( 'phone' ) : '' ) );
	}
	$back = isset( $_POST['back'] ) ? sanitize_key( $_POST['back'] ) : 'achplug';
	wp_safe_redirect( admin_url( 'admin.php?page=' . $back ) ); exit;
} );
add_action( 'admin_post_achplug_sent', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'achplug_sent' ) ) wp_die( 'No.' );
	foreach ( achplug_orders( 'authorized', -1 ) as $o ) { update_post_meta( $o->ID, 'status', 'collecting' ); update_post_meta( $o->ID, 'sent_at', current_time( 'mysql' ) ); }
	wp_safe_redirect( admin_url( 'admin.php?page=achplug-collect' ) ); exit;
} );
add_action( 'admin_init', function () {
	if ( isset( $_GET['page'], $_GET['achplug_file'] ) && $_GET['page'] === 'achplug-collect' && current_user_can( 'manage_options' ) && check_admin_referer( 'achplug_file' ) ) {
		$txt = achplug_nacha(); if ( is_wp_error( $txt ) ) wp_die( $txt->get_error_message() );
		header( 'Content-Type: text/plain' ); header( 'Content-Disposition: attachment; filename="achplug-debits-' . date( 'Y-m-d' ) . '.ach"' ); echo $txt; exit;
	}
	if ( isset( $_GET['page'], $_GET['achplug_csv'] ) && $_GET['page'] === 'achplug-journal' && current_user_can( 'manage_options' ) ) {
		header( 'Content-Type: text/csv' ); header( 'Content-Disposition: attachment; filename="sales-journal-ach-' . date( 'Y-m-d' ) . '.csv"' );
		$f = fopen( 'php://output', 'w' ); fputcsv( $f, array( 'Reference', 'Date created', 'Date received', 'Status', 'Customer', 'Email', 'Product', 'Bank', 'Amount' ) );
		foreach ( achplug_journal_rows() as $r ) fputcsv( $f, array( $r['ref'], $r['created'], $r['paid_at'], $r['status'], $r['name'], $r['email'], $r['product'], $r['bank'], number_format( $r['amount'], 2, '.', '' ) ) );
		exit;
	}
} );

/* ---- NACHA PPD debit file ---- */
function achplug_nacha() {
	if ( ! achplug_collect_setup() ) return new WP_Error( 'setup', 'Enter your Company ID and origination routing number in Settings → 6 first.' );
	$rows = achplug_orders( 'authorized', -1 ); if ( ! $rows ) return new WP_Error( 'empty', 'Nothing to collect.' );
	$pad = fn( $v, $n, $right = false, $ch = ' ' ) => $right ? str_pad( substr( (string) $v, 0, $n ), $n, $ch, STR_PAD_LEFT ) : str_pad( substr( (string) $v, 0, $n ), $n, $ch );
	$num = fn( $v, $n ) => $pad( preg_replace( '/\D/', '', (string) $v ), $n, true, '0' );
	$now = time(); $yymmdd = gmdate( 'ymd', $now ); $hhmm = gmdate( 'Hi', $now ); $eff = gmdate( 'ymd', $now + 86400 );
	$dest = $num( achplug_opt( 'odfi_routing' ), 9 ); $cid = preg_replace( '/\D/', '', achplug_opt( 'company_id' ) );
	$origin = $pad( substr( '1' . $cid, 0, 10 ), 10, true, '0' ); $coName = $pad( strtoupper( achplug_opt( 'entity' ) ), 16 ); $coId = $pad( substr( $cid, 0, 10 ), 10 );
	$lines = array();
	$lines[] = '101 ' . $dest . $origin . $yymmdd . $hhmm . 'A094101' . $pad( strtoupper( achplug_opt( 'bank' ) ?: 'BANK' ), 23 ) . $pad( strtoupper( achplug_opt( 'entity' ) ), 23 ) . $pad( '', 8 );
	$lines[] = '5225' . $coName . $pad( '', 20 ) . $coId . 'PPD' . $pad( 'PAYMENT', 10 ) . $pad( '', 6 ) . $eff . $pad( '', 3 ) . '1' . substr( $dest, 0, 8 ) . $num( 1, 7 );
	$hash = 0; $total = 0; $seq = 0;
	foreach ( $rows as $o ) {
		$d = json_decode( achplug_decrypt( get_post_meta( $o->ID, 'enc', true ) ), true ); if ( ! $d ) continue; $seq++;
		$tc = get_post_meta( $o->ID, 'acct_type', true ) === 'savings' ? '37' : '27'; $cents = (int) round( (float) get_post_meta( $o->ID, 'amount', true ) * 100 );
		$hash += (int) substr( $d['routing'], 0, 8 ); $total += $cents;
		$lines[] = '6' . $tc . substr( $d['routing'], 0, 8 ) . substr( $d['routing'], 8, 1 ) . $pad( $d['account'], 17 ) . $num( $cents, 10 ) . $pad( $o->post_title, 15 ) . $pad( strtoupper( get_post_meta( $o->ID, 'name', true ) ), 22 ) . '  0' . substr( $dest, 0, 8 ) . $num( $seq, 7 );
	}
	$bh = $num( $hash % 10000000000, 10 );
	$lines[] = '8225' . $num( $seq, 6 ) . $bh . $num( $total, 12 ) . $num( 0, 12 ) . $coId . $pad( '', 19 ) . $pad( '', 6 ) . substr( $dest, 0, 8 ) . $num( 1, 7 );
	$blocks = (int) ceil( ( count( $lines ) + 1 ) / 10 );
	$lines[] = '9' . $num( 1, 6 ) . $num( $blocks, 6 ) . $num( $seq, 8 ) . $bh . $num( $total, 12 ) . $num( 0, 12 ) . $pad( '', 39 );
	while ( count( $lines ) % 10 ) $lines[] = str_repeat( '9', 94 );
	return implode( "\r\n", $lines ) . "\r\n";
}

/* ---- pages ---- */
function achplug_row_form( $id, $back, $paid_label = 'Received' ) {
	$s = get_post_meta( $id, 'status', true ); $h = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:4px;flex-wrap:wrap">' . wp_nonce_field( 'achplug_mark', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="achplug_mark"><input type="hidden" name="id" value="' . (int) $id . '"><input type="hidden" name="back" value="' . esc_attr( $back ) . '">';
	if ( $s !== 'paid' ) $h .= '<input type="url" name="link" placeholder="Link to email them (optional)" style="width:200px"><button class="button button-primary" name="to" value="paid">' . $paid_label . '</button><button class="button" name="to" value="cancelled">' . ( $s === 'collecting' ? 'Returned' : 'Cancel' ) . '</button>';
	else $h .= '<button class="button" name="to" value="awaiting">Undo</button>';
	return $h . '</form>';
}
function achplug_dashboard_page() {
	achplug_head( 'Dashboard' );
	$ready = achplug_orders( 'authorized', -1 ); $coll = achplug_orders( 'collecting', -1 ); $wait = achplug_orders( 'awaiting' );
	if ( ! achplug_ready() ) echo '<div class="achplug-notice"><b>First:</b> enter your payee name in <a href="' . esc_url( admin_url( 'admin.php?page=achplug-settings' ) ) . '">Settings</a>. The box stays hidden on your site until you do. New here? <a href="' . esc_url( admin_url( 'admin.php?page=achplug-start' ) ) . '">Getting started</a>.</div>';
	echo '<div class="achplug-cards"><div><small>Authorized, ready to collect</small><b>' . count( $ready ) . '</b><small><a href="' . esc_url( admin_url( 'admin.php?page=achplug-collect' ) ) . '">Open Collect</a></small></div><div><small>Sent to bank, waiting to clear</small><b>' . count( $coll ) . '</b></div><div><small>Repeating payments active</small><b>' . count( array_filter( achplug_orders( array( 'authorized', 'collecting', 'paid' ), -1 ), fn( $o ) => get_post_meta( $o->ID, 'plan_status', true ) === 'active' ) ) . '</b></div></div>';
	echo '<h2>Your box</h2><p>Edit any page, press <strong>+</strong>, search <strong>ACHplug</strong>, drag the block in and set the name and price. Or paste: <code>[achplug name="What you sell" price="20"]</code></p>';
	if ( $wait ) { echo '<h2>Waiting for money — customers sending it themselves</h2><table class="widefat striped"><thead><tr><th>Ref</th><th>When</th><th>Customer</th><th>Product</th><th>Amount</th><th>Action</th></tr></thead><tbody>'; foreach ( $wait as $o ) echo '<tr><td><code>' . esc_html( $o->post_title ) . '</code></td><td>' . esc_html( get_date_from_gmt( $o->post_date_gmt, 'j M Y' ) ) . '</td><td>' . esc_html( get_post_meta( $o->ID, 'name', true ) ) . '<br><a href="mailto:' . esc_attr( get_post_meta( $o->ID, 'email', true ) ) . '">' . esc_html( get_post_meta( $o->ID, 'email', true ) ) . '</a></td><td>' . esc_html( get_post_meta( $o->ID, 'product', true ) ) . '</td><td>' . esc_html( achplug_money( get_post_meta( $o->ID, 'amount', true ) ) ) . '</td><td>' . achplug_row_form( $o->ID, 'achplug', 'Mark received' ) . '</td></tr>'; echo '</tbody></table>'; }
	$plans = array_filter( achplug_orders( array( 'authorized', 'collecting', 'paid', 'revoked' ), -1 ), fn( $o ) => get_post_meta( $o->ID, 'interval', true ) );
	echo '<h2>Repeating payments</h2>';
	if ( ! $plans ) echo '<p>None yet. When a customer selects "repeat this payment" in the box, it appears here.</p>';
	else { echo '<table class="widefat striped"><thead><tr><th>Ref</th><th>Customer</th><th>Product</th><th>Amount</th><th>Every</th><th>Ends</th><th>Next</th><th>Status</th></tr></thead><tbody>'; foreach ( $plans as $o ) { $m = fn( $k ) => get_post_meta( $o->ID, $k, true ); echo '<tr><td><code>' . esc_html( $o->post_title ) . '</code></td><td>' . esc_html( $m( 'name' ) ) . '</td><td>' . esc_html( $m( 'product' ) ) . '</td><td>' . esc_html( achplug_money( $m( 'amount' ) ) ) . '</td><td>' . esc_html( $m( 'interval' ) ) . '</td><td>' . esc_html( $m( 'end_count' ) ? $m( 'done' ) . ' of ' . $m( 'end_count' ) : ( $m( 'end_date' ) ?: 'when stopped' ) ) . '</td><td>' . esc_html( $m( 'next_due' ) ) . '</td><td>' . esc_html( $m( 'plan_status' ) ) . '</td></tr>'; } echo '</tbody></table>'; }
	echo '</div>';
}
function achplug_collect_page() {
	achplug_head( 'Collect', 'Payments your customers have authorized. Download the bank file, upload it to your bank\'s ACH origination page, press "I uploaded it." When the money shows in your account, press Received — the customer gets their receipt.' );
	$ready = achplug_orders( 'authorized', -1 ); $coll = achplug_orders( 'collecting', -1 ); $t = array_sum( array_map( fn( $o ) => (float) get_post_meta( $o->ID, 'amount', true ), $ready ) );
	if ( ! achplug_collect_setup() ) echo '<div class="achplug-notice"><b>One-time setup.</b> Your bank needs two things in every file: your <b>Company ID</b> (your EIN, or the originator ID your bank gave you) and the <b>routing number your bank uses for ACH origination</b>. Enter both in <a href="' . esc_url( admin_url( 'admin.php?page=achplug-settings' ) ) . '">Settings → 6. Collecting</a>. What to say to your bank, word for word: <a href="https://achplug.com/help-collect.html" target="_blank" rel="noopener">achplug.com/help-collect</a></div>';
	echo '<h2>Ready to collect (' . count( $ready ) . ') · ' . esc_html( achplug_money( $t ) ) . '</h2>';
	if ( $ready ) { echo '<table class="widefat striped"><thead><tr><th>Ref</th><th>Customer</th><th>Product</th><th>Bank</th><th>Amount</th></tr></thead><tbody>'; foreach ( $ready as $o ) echo '<tr><td><code>' . esc_html( $o->post_title ) . '</code></td><td>' . esc_html( get_post_meta( $o->ID, 'name', true ) ) . '<br><a href="mailto:' . esc_attr( get_post_meta( $o->ID, 'email', true ) ) . '">' . esc_html( get_post_meta( $o->ID, 'email', true ) ) . '</a></td><td>' . esc_html( get_post_meta( $o->ID, 'product', true ) ) . '</td><td>' . esc_html( get_post_meta( $o->ID, 'bank_name', true ) ) . ' ····' . esc_html( get_post_meta( $o->ID, 'last4', true ) ) . '</td><td>' . esc_html( achplug_money( get_post_meta( $o->ID, 'amount', true ) ) ) . '</td></tr>'; echo '</tbody></table>';
		if ( achplug_collect_setup() ) echo '<p style="margin-top:12px"><a class="achplug-cta" href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?page=achplug-collect&achplug_file=1' ), 'achplug_file' ) ) . '">Download bank file (' . count( $ready ) . ' payments, ' . esc_html( achplug_money( $t ) ) . ')</a> &nbsp; <form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">' . wp_nonce_field( 'achplug_sent', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="achplug_sent"><button class="button">I uploaded it — mark all as sent to bank</button></form></p>';
		else echo '<p><em>Finish the setup above to download the file.</em></p>'; }
	else echo '<p>Nothing waiting. When a customer approves a payment it appears here.</p>';
	echo '<h2>Sent to bank — waiting to clear</h2>';
	if ( $coll ) { echo '<table class="widefat striped"><thead><tr><th>Ref</th><th>Customer</th><th>Bank</th><th>Amount</th><th>Sent</th><th>Action</th></tr></thead><tbody>'; foreach ( $coll as $o ) echo '<tr><td><code>' . esc_html( $o->post_title ) . '</code></td><td>' . esc_html( get_post_meta( $o->ID, 'name', true ) ) . '</td><td>' . esc_html( get_post_meta( $o->ID, 'bank_name', true ) ) . ' ····' . esc_html( get_post_meta( $o->ID, 'last4', true ) ) . '</td><td>' . esc_html( achplug_money( get_post_meta( $o->ID, 'amount', true ) ) ) . '</td><td>' . esc_html( substr( (string) get_post_meta( $o->ID, 'sent_at', true ), 0, 10 ) ) . '</td><td>' . achplug_row_form( $o->ID, 'achplug-collect' ) . '</td></tr>'; echo '</tbody></table>'; }
	else echo '<p>None.</p>';
	echo '</div>';
}
function achplug_journal_rows() {
	$out = array();
	foreach ( achplug_orders( '', -1 ) as $o ) $out[] = array( 'id' => $o->ID, 'ref' => $o->post_title, 'created' => get_date_from_gmt( $o->post_date_gmt, 'Y-m-d' ), 'paid_at' => substr( (string) get_post_meta( $o->ID, 'paid_at', true ), 0, 10 ), 'status' => get_post_meta( $o->ID, 'status', true ), 'name' => get_post_meta( $o->ID, 'name', true ), 'email' => get_post_meta( $o->ID, 'email', true ), 'product' => get_post_meta( $o->ID, 'product', true ), 'bank' => trim( get_post_meta( $o->ID, 'bank_name', true ) . ( get_post_meta( $o->ID, 'last4', true ) ? ' ····' . get_post_meta( $o->ID, 'last4', true ) : '' ) ), 'amount' => (float) get_post_meta( $o->ID, 'amount', true ) );
	return $out;
}
function achplug_journal_page() {
	$all = achplug_journal_rows(); $v = isset( $_GET['v'] ) ? sanitize_key( $_GET['v'] ) : 'unpaid'; $q = isset( $_GET['q'] ) ? strtolower( sanitize_text_field( $_GET['q'] ) ) : '';
	$paid = array_filter( $all, fn( $r ) => $r['status'] === 'paid' ); $sum = fn( $a ) => array_sum( array_map( fn( $r ) => $r['amount'], $a ) );
	$since = fn( $d ) => array_filter( $paid, fn( $r ) => ( $r['paid_at'] ?: $r['created'] ) >= $d );
	$wk = $since( date( 'Y-m-d', strtotime( '-7 days' ) ) ); $mo = $since( date( 'Y-m-01' ) ); $yr = $since( date( 'Y-01-01' ) );
	$open = array_filter( $all, fn( $r ) => in_array( $r['status'], array( 'awaiting', 'authorized', 'collecting' ), true ) );
	$shown = array_filter( $all, fn( $r ) => ( $v === 'all' || ( $v === 'paid' ? $r['status'] === 'paid' : $r['status'] !== 'paid' ) ) && ( ! $q || strpos( strtolower( $r['ref'] . ' ' . $r['name'] . ' ' . $r['email'] . ' ' . $r['product'] ), $q ) !== false ) );
	$fees = array_sum( array_map( fn( $r ) => $r['amount'] * 0.029 + 0.30, $paid ) ); $base = admin_url( 'admin.php?page=achplug-journal' );
	$tab = fn( $k, $l ) => '<a class="achplug-tab' . ( $v === $k ? ' current' : '' ) . '" href="' . esc_url( add_query_arg( array( 'v' => $k, 'q' => $q ), $base ) ) . '">' . $l . '</a>';
	achplug_head( 'Sales Journal — ACH payments', 'Every ACH payment your site has taken. <a href="' . esc_url( add_query_arg( 'achplug_csv', 1, $base ) ) . '">Download CSV</a> for your accountant.' );
	echo '<div class="achplug-cards"><div><small>Last 7 days</small><b>' . esc_html( achplug_money( $sum( $wk ) ) ) . '</b><small>' . count( $wk ) . ' payments</small></div><div><small>This month</small><b>' . esc_html( achplug_money( $sum( $mo ) ) ) . '</b><small>' . count( $mo ) . '</small></div><div><small>This year</small><b>' . esc_html( achplug_money( $sum( $yr ) ) ) . '</b><small>' . count( $yr ) . '</small></div><div><small>All time</small><b>' . esc_html( achplug_money( $sum( $paid ) ) ) . '</b><small>' . count( $paid ) . '</small></div><div><small>Open — not yet received</small><b>' . esc_html( achplug_money( $sum( $open ) ) ) . '</b><small>' . count( $open ) . '</small></div><div><small>Card fees you did not pay</small><b>' . esc_html( achplug_money( $fees ) ) . '</b><small>at 2.9% + 30¢</small></div></div>';
	echo '<form method="get" style="margin:10px 0"><input type="hidden" name="page" value="achplug-journal"><input type="hidden" name="v" value="' . esc_attr( $v ) . '">' . $tab( 'unpaid', 'Unpaid (' . count( array_filter( $all, fn( $r ) => $r['status'] !== 'paid' ) ) . ')' ) . $tab( 'paid', 'Paid (' . count( $paid ) . ')' ) . $tab( 'all', 'All (' . count( $all ) . ')' ) . ' <input name="q" value="' . esc_attr( $q ) . '" placeholder="Search name, email, reference, product"> <button class="button">Search</button></form>';
	echo '<table class="widefat striped"><thead><tr><th>Reference</th><th>Created</th><th>Received</th><th>Status</th><th>Customer</th><th>Product</th><th>Bank</th><th>Amount</th><th>Action</th></tr></thead><tbody>';
	if ( ! $shown ) echo '<tr><td colspan="9">Nothing here yet.</td></tr>';
	foreach ( $shown as $r ) { $style = $r['status'] === 'paid' ? 'color:#1E6B4E;font-weight:600' : ( in_array( $r['status'], array( 'cancelled', 'revoked' ), true ) ? 'color:#888' : 'color:#b45309;font-weight:600' ); echo '<tr><td><code>' . esc_html( $r['ref'] ) . '</code></td><td>' . esc_html( $r['created'] ) . '</td><td>' . esc_html( $r['paid_at'] ) . '</td><td style="' . $style . '">' . esc_html( ucfirst( $r['status'] ) ) . '</td><td>' . esc_html( $r['name'] ) . '<br><a href="mailto:' . esc_attr( $r['email'] ) . '">' . esc_html( $r['email'] ) . '</a></td><td>' . esc_html( $r['product'] ) . '</td><td>' . esc_html( $r['bank'] ) . '</td><td>' . esc_html( achplug_money( $r['amount'] ) ) . '</td><td>' . ( in_array( $r['status'], array( 'cancelled', 'revoked' ), true ) ? '' : achplug_row_form( $r['id'], 'achplug-journal' ) ) . '</td></tr>'; }
	echo '</tbody></table></div>';
}
function achplug_start_page() { $ready = achplug_ready(); $setup = achplug_collect_setup(); achplug_head( 'Getting started with ACHplug' ); ?>
	<h2 style="margin-top:4px">Watch it first — 90 seconds</h2>
	<iframe src="<?php echo esc_url( ACHPLUG_URL . 'assets/howto.html' ); ?>" title="How to set up ACHplug" style="width:100%;max-width:980px;height:640px;border:1px solid #c3c4c7;border-radius:10px;background:#fff" loading="lazy"></iframe>
	<h2>Then, the three steps</h2>
	<p style="font-size:15px;max-width:72ch"><b>For businesses and nonprofits.</b> ACHplug puts a box on your site where a customer or donor enters their bank details and approves a payment — one time, or repeating. Your own bank collects it. Three steps to set up, one minute a day to run.</p>
	<ol class="achplug-steps">
		<li><b>Settings — who you are and where the money goes <?php if ( $ready ) echo '<span style="color:#1E6B4E">— done</span>'; ?></b><a href="<?php echo esc_url( admin_url( 'admin.php?page=achplug-settings' ) ); ?>">ACHplug → Settings</a>: your payee name, your address (printed on the customer's confirmation), the discount you want to give for paying by bank (0 to 90), and whether customers may set up repeating payments.</li>
		<li><b>Settings — what your bank needs to collect <?php if ( $setup ) echo '<span style="color:#1E6B4E">— done</span>'; ?></b>Section 6: your Company ID (usually your EIN) and the routing number your bank uses for ACH origination. Getting these is one phone call to your bank's business line; <a href="https://achplug.com/help-collect.html" target="_blank" rel="noopener">here are the words to use</a>.</li>
		<li><b>Put the box on a page</b>Edit any page, press <strong>+</strong>, search <strong>ACHplug</strong>, drag the block in, type what you sell and the price. Or paste <code>[achplug name="What you sell" price="20"]</code>. Publish.</li>
	</ol>
	<h2>Then, each day there is something to collect</h2>
	<div class="achplug-cards"><div><small>1</small><b style="font-size:16px">Open Collect</b></div><div><small>2</small><b style="font-size:16px">Download the bank file</b></div><div><small>3</small><b style="font-size:16px">Upload it at your bank</b></div><div><small>4</small><b style="font-size:16px">Press "I uploaded it"</b></div><div><small>5</small><b style="font-size:16px">When it lands, press Received</b></div></div>
	<p>Step 5 sends the customer their receipt and moves the payment to the Sales Journal. An email each morning reminds you when there is something to collect.</p>
	<h2>Questions</h2>
	<p><strong>Where are my customers' account numbers?</strong> Encrypted in this site's database, with a key that never leaves it. You see the last four digits. The full number appears only inside the file your bank reads, and it is deleted when a customer revokes.</p>
	<p><strong>Can a customer stop a repeating payment?</strong> Yes — every email they get has a link to a page with a Revoke button. Nothing further is collected. You are told by email.</p>
	<p><strong>What if a payment bounces?</strong> Your bank tells you within a couple of days. Press Returned on the Collect page; the customer is emailed that it did not go through and is still owed.</p>
	<p>Help: <a href="mailto:realroofers@gmail.com">realroofers@gmail.com</a> · 732-995-3914 · <a href="https://achplug.com/features.html" target="_blank" rel="noopener">achplug.com/features</a></p>
	</div>
<?php }
function achplug_features_page() {
	achplug_head( 'Features and how ACHplug compares', 'For businesses and nonprofits — one-time and recurring bank payments. What you have, and what the alternatives cost.' );
	echo '<div class="achplug-card"><ul style="list-style:disc;margin-left:18px;line-height:1.7"><li><b>The checkout box</b> — card price and bank price side by side, your discount 0–90%; the customer enters routing and account number, approves, presses Buy. Bank name checked against the Federal Reserve directory as they type.</li><li><b>Collect</b> — approved payments in one list; one bank file to download; Received sends the receipt.</li><li><b>One-time and repeating payments</b> — a deposit today, or the customer approves once: weekly, monthly, yearly; until stopped, N payments, or a date. Each period appears on Collect by itself. Pause/Stop link in every email.</li><li><b>Sales Journal</b> — last 7 days, month, year, all time; Unpaid / Paid / All; search; CSV.</li><li><b>Two customer emails</b> with your own wording — confirmation with their authorization record, and the receipt.</li><li><b>Donation mode</b> — donor picks the amount, receipt carries your EIN and the IRS acknowledgment line.</li><li><b>Encryption</b> — customers\' account numbers are encrypted with a key that never leaves this site; you see the last four.</li><li><b>Fits your theme</b> — the box has no fonts or colours of its own.</li></ul></div>';
	$rows = array(
		array( 'How the money moves', 'Customer approves on your site; your bank collects', 'Stripe pulls (ACH debit)', 'Stripe pulls', 'Customer sends it; you match by hand', 'Stripe pulls' ),
		array( 'Company between you and your money', 'None', 'Stripe', 'Stripe', 'None', 'Stripe' ),
		array( 'Fee per payment', '$0 from ACHplug; your bank\'s ACH cost, often nothing', '0.8% capped at $5, plus $1.50 verification', 'Stripe\'s rate plus 3% on the free plan', '$0', '0.8%, cap $5' ),
		array( 'Software price', '$25 once', 'Paid license — ACH not in free version', 'Free with 3% fee, or paid license', 'Free, needs WooCommerce', 'Free, needs WooCommerce' ),
		array( 'Can your money be held', 'No', 'Yes', 'Yes', 'No', 'Yes' ),
		array( 'Recurring — contract paid off, service kept up', 'Yes; customer pauses or stops any time', 'Yes, via Stripe', 'Yes, via Stripe', 'No', 'Yes, via Stripe + Subscriptions' ),
		array( 'Discount for paying by bank', 'Built in, 0–90%', 'No', 'No', 'No', 'No' ),
		array( 'Customer\'s routing number checked vs Fed directory', 'Yes', 'n/a', 'n/a', 'No', 'n/a' ),
		array( 'Sales journal, week/month/year, CSV', 'Built in', 'Stripe dashboard', 'No', 'WooCommerce orders', 'Stripe dashboard' ),
		array( 'Several businesses under one login', 'Yes — on achplug.com: sites, switcher, all-sites journal', 'One Stripe account per site', 'One Stripe account per site', 'One install per site', 'One Stripe account per site' ),
		array( 'Works without a store platform', 'Yes', 'Yes', 'Yes', 'No', 'No' ),
	);
	echo '<h2>How it compares</h2><div style="overflow:auto"><table class="widefat achplug-cmp" style="min-width:820px"><thead><tr><th></th><th>ACHplug</th><th>WP Simple Pay Pro</th><th>Formidable Forms</th><th>WooCommerce Direct Bank Transfer</th><th>WooPayments / Stripe ACH</th></tr></thead><tbody>';
	foreach ( $rows as $r ) { echo '<tr>'; foreach ( $r as $i => $c ) echo '<td>' . esc_html( $c ) . '</td>'; echo '</tr>'; }
	echo '</tbody></table></div><p><small>Fees and features as published by each company, September 2026. What the others do better: faster confirmation in some cases, no bank setup on your side, and automatic handling of a bounced payment. ACHplug is for the seller whose payments are fewer and larger — deposits, contracts, monthly services — where 3% is real money and a held payout is a real problem.</small></p></div>';
}
function achplug_settings_page() {
	$o = wp_parse_args( (array) get_option( 'achplug_settings', array() ), achplug_defaults() );
	$f = function ( $k, $label, $help = '', $type = 'text' ) use ( $o ) {
		echo '<tr><th scope="row"><label for="ap_' . $k . '">' . esc_html( $label ) . '</label></th><td>';
		if ( $type === 'textarea' ) echo '<textarea id="ap_' . $k . '" name="achplug_settings[' . $k . ']" rows="6" class="large-text">' . esc_textarea( $o[ $k ] ) . '</textarea>';
		else echo '<input id="ap_' . $k . '" type="' . $type . '" name="achplug_settings[' . $k . ']" value="' . esc_attr( $o[ $k ] ) . '" class="regular-text">';
		if ( $help ) echo '<p class="description">' . $help . '</p>'; echo '</td></tr>';
	};
	$tile = fn( $name, $val, $checked, $b, $span ) => '<label class="achplug-tile"><input type="radio" name="achplug_settings[' . $name . ']" value="' . $val . '"' . ( $checked ? ' checked' : '' ) . '><b>' . $b . '</b><span>' . $span . '</span></label>';
	achplug_head( 'Settings' ); settings_errors( 'achplug' ); ?>
	<form method="post" action="options.php"><?php settings_fields( 'achplug' ); ?>
	<h2>1. What is this box for?</h2>
	<div class="achplug-tiles"><?php echo $tile( 'mode', 'sale', $o['mode'] !== 'donation', 'Selling something', 'The customer pays a price. You can give a discount for paying by bank.' ) . $tile( 'mode', 'donation', $o['mode'] === 'donation', 'Taking donations', 'The donor picks the amount. No discount. The receipt carries your tax ID.' ); ?></div>
	<h2>2. Who you are</h2><table class="form-table">
	<?php $f( 'entity', 'Pay to — your legal name, exactly as your bank has it', 'Printed on the customer\'s confirmation and their bank statement.' ); $f( 'address', 'Your business address', 'Printed on the customer\'s confirmation.' ); $f( 'email', 'Your email — new payments and questions come here', '', 'email' ); $f( 'phone', 'Phone (optional) — shown in the box' ); ?>
	</table>
	<h2>3. The offer</h2><table class="form-table">
	<?php $f( 'discount', 'Discount for paying by bank, % — 0 to 90, any number', 'Change it any time; every box updates.', 'number' ); $f( 'prefix', 'Order number prefix', 'Two or three letters that start every order number — JC gives JC-482913. Something that means something to you.' ); $f( 'card_url', 'Card checkout link (optional)', 'A Stripe Payment Link, PayPal, anything. Leave blank for bank only.', 'url' ); $f( 'ein', 'Tax ID / EIN — printed on donation receipts' ); $f( 'amounts', 'Suggested donation amounts (donation mode), comma-separated' ); ?>
	</table>
	<h2>4. Repeating payments</h2>
	<label class="achplug-tile" style="max-width:960px;padding-left:40px"><input type="checkbox" name="achplug_settings[recurring]" value="1"<?php checked( $o['recurring'], '1' ); ?>><b>Let customers select "repeat this payment"</b><span>Weekly, monthly or yearly — until they stop it, for a number of payments, or until a date. Each period appears on Collect by itself. Every email carries their Pause / Stop link.</span></label>
	<h2>5. How the money is collected</h2>
	<div class="achplug-tiles"><?php echo $tile( 'collect', 'pull', $o['collect'] !== 'push', 'Customer enters their bank details and approves', 'Your bank collects it from a file ACHplug builds. Their account number is encrypted; you see the last four.' ) . $tile( 'collect', 'push', $o['collect'] === 'push', 'Customer sends it from their bank', 'The box shows your payee name, routing and account number and the customer sends the money themselves.' ); ?></div>
	<div id="achplug-pull-only">	<h2>6. Collecting — what your bank needs in the file</h2><table class="form-table">
	<?php $f( 'company_id', 'Company ID — your EIN, or the originator ID your bank assigned' ); $f( 'odfi_routing', 'Routing number your bank uses for ACH origination', 'Ask your bank; often the same as your account\'s. <a href="https://achplug.com/help-collect.html" target="_blank" rel="noopener">What to say, word for word →</a>' ); ?>
	</table></div>
	<div id="achplug-push-only" style="<?php echo $o['collect'] === 'push' ? '' : 'display:none'; ?>"><h2>Because customers send the money themselves — where they send it</h2><table class="form-table">
	<?php $f( 'routing', 'Your routing number', 'Checked against the Federal Reserve directory when you save; the bank name fills in.' ); $f( 'bank', 'Bank name' ); $f( 'account', 'Your account number' ); $f( 'days', 'How long a transfer takes — shown to the customer' ); ?>
	</table></div>
	<script>(function(){var r=document.querySelectorAll('input[name="achplug_settings[collect]"]'),p=document.getElementById('achplug-push-only'),c=document.getElementById('achplug-pull-only');function u(){var push=document.querySelector('input[name="achplug_settings[collect]"]:checked').value==='push';p.style.display=push?'':'none';if(c)c.style.display=push?'none':'';}r.forEach(function(x){x.addEventListener('change',u);});u();})();</script>
	<h2>7. Emails to the customer</h2>
	<p class="description">Standard wording is used when a box is empty. You can use {name} {product} {ref} {amount} {date} {entity} {address_line} {bank} {last4} {acct_type} {repeat_line} {agreed} {ein} {link} {site} {revoke_line}.</p>
	<table class="form-table"><?php $f( 'ack_tpl', 'Sent the moment they approve', '<details><summary>Standard wording</summary><pre>' . esc_html( achplug_def_ack() ) . '</pre></details>', 'textarea' ); $f( 'receipt_tpl', 'Sent when you press Received — the receipt', '<details><summary>Standard wording</summary><pre>' . esc_html( $o['mode'] === 'donation' ? achplug_def_receipt_don() : achplug_def_receipt() ) . '</pre></details>', 'textarea' ); ?></table>
	<h2>8. Words inside the box</h2><table class="form-table">
	<?php $f( 'w_bank_label', 'Bank option label' ); $f( 'w_bank_button', 'Bank button' ); $f( 'w_save', 'Saving line (followed by the %)' ); $f( 'w_buy', 'Buy button' ); $f( 'w_thanks', 'Thank-you line' ); $f( 'card_label', 'Card button' ); $f( 'card_note', 'Small print under the card price' ); $f( 'explain', 'The explanation under "What is paying from my bank?"', '', 'textarea' ); ?>
	</table>
	<?php submit_button( 'SAVE' ); ?></form></div>
<?php }
