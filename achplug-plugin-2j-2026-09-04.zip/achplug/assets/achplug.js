/* ACHplug 2.0.0 — the box. Reads its config from data-cfg, talks to this site's REST API. */
(function(){
  function money(n){return '$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});}
  function e(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  document.querySelectorAll('.achplug[data-cfg]').forEach(function(host){
    var c;try{c=JSON.parse(host.getAttribute('data-cfg'));}catch(err){return;}
    var don=c.don,pull=c.pull,rec=c.rec,disc=Number(c.disc||0),price=Number(c.price||0),ach=Number(c.ach||0),card=c.card||'',ref='',repeat='',endc=0,endd='';
    var pick=don&&!price,amts=(c.amounts||[]).map(Number).filter(function(x){return x>0;});
    var w=c.w||{};var pct=(Math.round(disc*10)/10).toString();
    host.innerHTML='<div class="achplug-head"><h3 class="achplug-title">'+e(c.name)+'</h3>'+(c.desc?'<p class="achplug-desc">'+e(c.desc)+'</p>':'')+'</div>'
     +'<div class="achplug-screen is-on" data-screen="1"><div class="achplug-choice">'
     +(card?'<div class="achplug-opt achplug-card"><small>'+e(w.card_label||'Pay by card')+'</small><div class="achplug-price">'+money(price)+'</div><small>'+e(w.card_note||'')+'</small><a class="achplug-go" href="'+e(card)+'">'+e(w.card_label||'Pay by card')+'</a></div>':'')
     +'<div class="achplug-opt achplug-bank"><small>'+(don?'Give from your bank':e(w.bank_label||'Pay from your bank'))+'</small>'
     +(pick?'<div class="achplug-amts">'+amts.map(function(a){return '<button type="button" class="achplug-amt" data-amt="'+a+'">'+money(a)+'</button>';}).join('')+'<input type="number" min="1" step="1" class="achplug-other" placeholder="Other amount"></div>':'<div class="achplug-price">'+money(ach)+'</div>')
     +(disc>0?'<span class="achplug-was">'+money(price)+'</span><span class="achplug-save">'+e(w.save||'You save')+' '+pct+'%</span>':(don?'<small>No card fees taken. 100% arrives.</small>':''))
     +'<button type="button" class="achplug-go" data-go="2">'+(don?'Give from my bank':e(w.bank_button||'Pay from my bank'))+'</button></div></div>'
     +'<details class="achplug-why"><summary>'+(don?'What is giving from my bank?':'What is paying from my bank?')+'</summary><p>'+e(c.explain)+'</p></details></div>'
     +(pull?
      '<div class="achplug-screen" data-screen="2"><label class="achplug-field"><span>Your name</span><input type="text" name="name" autocomplete="name" placeholder="As it appears on your bank account"></label><label class="achplug-field"><span>Email — your receipt goes here</span><input type="email" name="email" autocomplete="email" placeholder="you@example.com"></label>'
      +'<div class="achplug-slip"><h4>Your bank account</h4><label class="achplug-field"><span>Routing number (9 digits)</span><input type="text" inputmode="numeric" name="routing" maxlength="9" placeholder="Bottom left of a check"><small class="achplug-bank"></small></label><label class="achplug-field"><span>Account number</span><input type="text" inputmode="numeric" name="account" maxlength="17" placeholder="Next to the routing number on a check"></label><label class="achplug-field"><span>Account type</span><select name="acct_type"><option value="checking">Checking</option><option value="savings">Savings</option></select></label></div>'
      +(rec?'<div class="achplug-rec"><label><input type="checkbox" class="achplug-rec-cb"> <b>Repeat this payment</b> every <select class="achplug-rec-int"><option value="monthly">month</option><option value="weekly">week</option><option value="yearly">year</option></select></label><div class="achplug-rec-end"><label><input type="radio" name="achplug-end" value="never" checked> until I stop it</label> <label><input type="radio" name="achplug-end" value="count"> for <input type="number" min="2" max="999" class="achplug-rec-count" value="12" style="width:64px"> payments</label> <label><input type="radio" name="achplug-end" value="date"> until <input type="date" class="achplug-rec-date"></label></div><p>You can pause or stop this any time from the link in your email. Nobody can collect after you stop it.</p></div>':'')
      +'<label class="achplug-agree"><input type="checkbox" name="agree"> <span>I authorize <b>'+e(c.entity)+'</b> to collect <b class="achplug-amt-out">'+money(ach)+'</b> from this account'+(rec?', and each repeat if I chose one,':'')+' and I understand I can revoke this any time from the link in my email.</span></label>'
      +'<p class="achplug-err" hidden></p><button type="button" class="achplug-primary" data-go="3">'+(don?'Give':e(w.buy||'Buy'))+' — <span class="achplug-amt-out">'+money(ach)+'</span></button><button type="button" class="achplug-ghost" data-go="1">Back</button></div>'
      :
      '<div class="achplug-screen" data-screen="2"><label class="achplug-field"><span>Your name</span><input type="text" name="name" autocomplete="name"></label><label class="achplug-field"><span>Email — we unlock your purchase here</span><input type="email" name="email" autocomplete="email" placeholder="you@example.com"></label>'
      +'<div class="achplug-slip"><h4>Send this from your bank</h4><div class="achplug-row"><span>Amount</span><b class="achplug-big achplug-amt-out">'+money(ach)+'</b></div><div class="achplug-row"><span>Pay to</span><b>'+e(c.entity)+'</b></div>'+(c.bank?'<div class="achplug-row"><span>Bank</span><b>'+e(c.bank)+'</b></div>':'')
      +'<div class="achplug-row"><span>Routing number</span><b>'+e(c.routing)+' <button type="button" class="achplug-copy" data-copy="'+e(c.routing)+'">Copy</button></b></div><div class="achplug-row"><span>Account number</span><b>'+e(c.account)+' <button type="button" class="achplug-copy" data-copy="'+e(c.account)+'">Copy</button></b></div><div class="achplug-row"><span>Memo / reference</span><b><span class="achplug-ref">—</span> <button type="button" class="achplug-copy" data-copy-ref>Copy</button></b></div></div>'
      +'<p class="achplug-err" hidden></p><button type="button" class="achplug-primary" data-go="3">I\'ve sent it</button><button type="button" class="achplug-ghost" data-go="1">Back</button></div>')
     +'<div class="achplug-screen" data-screen="3"><div class="achplug-done"><div class="achplug-mark">&#10003;</div><h4>'+e(w.thanks||'Thank you.')+'</h4>'+(pull?'<p class="achplug-notice"></p>':'<p>Keep this reference. When your transfer lands — '+e(c.days)+' — you will get a receipt at the address you gave.</p>')+'<div class="achplug-ord achplug-ref">—</div></div></div>'
     +'<div class="achplug-foot"><span>'+(c.contact?'Questions? '+e(c.contact):'')+'</span><span>Pay-from-bank checkout by <a href="https://achplug.com" rel="noopener" style="display:inline-flex;align-items:center;gap:4px"><svg viewBox="0 0 64 64" width="14" height="14" aria-hidden="true"><circle cx="32" cy="24" r="17" fill="#1E6B4E"/><circle cx="19" cy="30" r="10" fill="#1E6B4E"/><circle cx="45" cy="30" r="10" fill="#1E6B4E"/><path d="M29 38h6v14a3 3 0 0 1-6 0z" fill="#8a5a2b"/><path d="M22 56c4-3 16-3 20 0" fill="none" stroke="#8a5a2b" stroke-width="3" stroke-linecap="round"/><circle cx="40" cy="43" r="7.5" fill="#E8A33D"/><rect x="36.8" y="35" width="2.2" height="5" rx="1.1" fill="#F7F9F6"/><rect x="41" y="35" width="2.2" height="5" rx="1.1" fill="#F7F9F6"/><path d="M37 43.5l2 2 4-4" fill="none" stroke="#F7F9F6" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="24" cy="26" r="3" fill="#E8A33D"/><circle cx="33" cy="14" r="3" fill="#E8A33D"/></svg> ACHplug</a></span></div>';
    var err=host.querySelector('.achplug-err');
    function show(n){host.querySelectorAll('.achplug-screen').forEach(function(x){x.classList.toggle('is-on',x.getAttribute('data-screen')==String(n));});host.scrollIntoView({block:'start',behavior:'smooth'});}
    function setRef(r){ref=r;host.querySelectorAll('.achplug-ref').forEach(function(x){x.textContent=r;});}
    function setAmt(a){ach=Math.round(a*100)/100;host.querySelectorAll('.achplug-amt-out').forEach(function(x){x.textContent=money(ach);});host.querySelectorAll('.achplug-amt').forEach(function(x){x.classList.toggle('is-on',Number(x.getAttribute('data-amt'))===ach);});}
    if(pick&&amts.length)setAmt(amts[0]);
    var oth=host.querySelector('.achplug-other');if(oth)oth.addEventListener('input',function(){if(Number(oth.value)>0)setAmt(Number(oth.value));});
    var rcb=host.querySelector('.achplug-rec-cb'),rint=host.querySelector('.achplug-rec-int');
    function upd(){repeat=rcb&&rcb.checked?rint.value:'';var m=host.querySelector('input[name=achplug-end]:checked');var v=m?m.value:'never';endc=v==='count'?Number(host.querySelector('.achplug-rec-count').value)||0:0;endd=v==='date'?host.querySelector('.achplug-rec-date').value:'';var en=host.querySelector('.achplug-rec-end');if(en)en.style.display=rcb&&rcb.checked?'':'none';}
    if(rcb){var rp=host.querySelector('.achplug-rec');rp.addEventListener('change',upd);rp.addEventListener('input',upd);upd();}
    var rin=host.querySelector('input[name=routing]'),bn=host.querySelector('.achplug-bank');
    if(rin)rin.addEventListener('input',function(){var v=rin.value.replace(/\D/g,'');rin.value=v;if(v.length===9){fetch(ACHPLUG.rest+'bank?rn='+v).then(function(r){return r.json();}).then(function(j){bn.textContent=j.ok&&j.name?j.name+(j.city?', '+j.city:'')+(j.state?' '+j.state:''):(j.ok?'':'Not a valid routing number');bn.style.color=j.ok?'':'#b91c1c';});}else bn.textContent='';});
    host.addEventListener('click',function(ev){
      var am=ev.target.closest('.achplug-amt');if(am){setAmt(Number(am.getAttribute('data-amt')));if(oth)oth.value='';return;}
      var t=ev.target.closest('[data-go],[data-copy],[data-copy-ref]');if(!t)return;
      if(t.hasAttribute('data-copy')||t.hasAttribute('data-copy-ref')){var txt=t.hasAttribute('data-copy-ref')?ref:t.getAttribute('data-copy');if(navigator.clipboard)navigator.clipboard.writeText(txt);t.classList.add('is-done');t.textContent='Copied';setTimeout(function(){t.classList.remove('is-done');t.textContent='Copy';},1500);return;}
      var go=t.getAttribute('data-go');if(go==='2'&&!(ach>0))return;if(go==='3'){submit(t);return;}show(go);
    });
    function post(path,body){return fetch(ACHPLUG.rest+path,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':ACHPLUG.nonce},body:JSON.stringify(body)}).then(function(r){return r.json().then(function(j){return {ok:r.ok,j:j};});});}
    function submit(btn){
      var name=host.querySelector('input[name=name]').value.trim(),email=host.querySelector('input[name=email]').value.trim();err.hidden=true;
      if(!name||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){err.textContent='Please give your name and a working email address.';err.hidden=false;return;}
      var label=btn.innerHTML;btn.disabled=true;btn.textContent='Sending…';
      var p;
      if(pull){var routing=host.querySelector('input[name=routing]').value.trim(),account=host.querySelector('input[name=account]').value.trim(),agree=host.querySelector('input[name=agree]').checked,at=host.querySelector('select[name=acct_type]').value;
        if(!/^\d{9}$/.test(routing)||account.length<4){btn.disabled=false;btn.innerHTML=label;err.textContent='Please enter your 9-digit routing number and your account number.';err.hidden=false;return;}
        if(!agree){btn.disabled=false;btn.innerHTML=label;err.textContent='Please check the box to authorize the payment.';err.hidden=false;return;}
        p=post('authorize',{name:name,email:email,product:c.name,sku:c.sku||'',amount:ach,routing:routing,account:account,acct_type:at,agree:1,repeat:repeat,end_count:endc,end_date:endd});
      }else p=post('order',{name:name,email:email,product:c.name,sku:c.sku||'',amount:ach});
      p.then(function(x){btn.disabled=false;btn.innerHTML=label;if(!x.ok){err.textContent=(x.j&&x.j.message)||'Something went wrong. Try again.';err.hidden=false;return;}setRef(x.j.ref);var nt=host.querySelector('.achplug-notice');if(nt&&x.j.notice)nt.textContent=x.j.notice;host.querySelectorAll('input[name=routing],input[name=account]').forEach(function(i){i.value='';});show(3);})
       .catch(function(){btn.disabled=false;btn.innerHTML=label;err.textContent='Could not reach the site. Try again.';err.hidden=false;});
    }
  });
})();
