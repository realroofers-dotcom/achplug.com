/* ACHplug block 2.0.0 (2c) — drag the ACHplug box into any page */
( function ( blocks, element, components, editor ) {
	var el = element.createElement, Text = components.TextControl, Panel = components.PanelBody;
	blocks.registerBlockType( 'achplug/box', {
		title: 'ACHplug — pay from your bank',
		description: 'A checkout box where your customer approves a bank payment — once or repeating. Your bank collects it.',
		icon: el( 'svg', { viewBox: '0 0 64 64', width: 24, height: 24 }, el( 'circle', { cx: 32, cy: 24, r: 17, fill: '#1E6B4E' } ), el( 'circle', { cx: 19, cy: 30, r: 10, fill: '#1E6B4E' } ), el( 'circle', { cx: 45, cy: 30, r: 10, fill: '#1E6B4E' } ), el( 'path', { d: 'M29 38h6v14a3 3 0 0 1-6 0z', fill: '#8a5a2b' } ), el( 'path', { d: 'M22 56c4-3 16-3 20 0', fill: 'none', stroke: '#8a5a2b', strokeWidth: 3, strokeLinecap: 'round' } ), el( 'circle', { cx: 40, cy: 43, r: 7.5, fill: '#E8A33D' } ), el( 'rect', { x: 36.8, y: 35, width: 2.2, height: 5, rx: 1.1, fill: '#F7F9F6' } ), el( 'rect', { x: 41, y: 35, width: 2.2, height: 5, rx: 1.1, fill: '#F7F9F6' } ), el( 'path', { d: 'M37 43.5l2 2 4-4', fill: 'none', stroke: '#F7F9F6', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' } ), el( 'circle', { cx: 24, cy: 26, r: 3, fill: '#E8A33D' } ), el( 'circle', { cx: 33, cy: 14, r: 3, fill: '#E8A33D' } ) ), category: 'widgets', keywords: [ 'ach', 'bank', 'pay', 'checkout', 'donate' ],
		attributes: { name: { type: 'string', default: 'What you sell' }, price: { type: 'string', default: '20' }, desc: { type: 'string', default: '' }, sku: { type: 'string', default: '' } },
		edit: function ( p ) {
			var a = p.attributes, set = p.setAttributes;
			return [
				el( editor.InspectorControls, { key: 'i' }, el( Panel, { title: 'What are you selling?', initialOpen: true },
					el( Text, { label: 'Name', value: a.name, onChange: function ( v ) { set( { name: v } ); } } ),
					el( Text, { label: 'Price in dollars (card price; the bank discount is applied automatically)', value: a.price, onChange: function ( v ) { set( { price: v } ); } } ),
					el( Text, { label: 'One line about it (optional)', value: a.desc, onChange: function ( v ) { set( { desc: v } ); } } ),
					el( Text, { label: 'Reference prefix for this item (optional, 2-3 letters)', value: a.sku, onChange: function ( v ) { set( { sku: v } ); } } ) ) ),
				el( 'div', { key: 'p', style: { border: '1.5px solid #1E6B4E', borderRadius: '10px', padding: '16px', background: '#F7F9F6', fontFamily: 'inherit' } },
					el( 'div', { style: { fontWeight: 600, fontSize: '18px' } }, a.name || 'What you sell' ),
					a.desc ? el( 'div', { style: { opacity: .7, fontSize: '14px' } }, a.desc ) : null,
					el( 'div', { style: { display: 'flex', gap: '12px', marginTop: '10px', flexWrap: 'wrap' } },
						el( 'div', { style: { flex: 1, minWidth: '160px', border: '1px solid #ccd', borderRadius: '8px', padding: '10px' } }, el( 'small', null, 'Pay by card' ), el( 'div', { style: { fontSize: '26px', fontWeight: 600 } }, '$' + ( Number( a.price ) || 0 ).toFixed( 2 ) ) ),
						el( 'div', { style: { flex: 1, minWidth: '160px', border: '1.5px solid #1E6B4E', borderRadius: '8px', padding: '10px' } }, el( 'small', null, 'Pay from your bank' ), el( 'div', { style: { fontSize: '26px', fontWeight: 600 } }, 'discount applied' ), el( 'small', { style: { color: '#1E6B4E', fontWeight: 600 } }, 'set in ACHplug → Settings' ) ) ),
					el( 'div', { style: { fontSize: '12px', opacity: .6, marginTop: '8px' } }, 'ACHplug box — the real prices show on the live page. Edit name and price in the panel on the right.' ) )
			];
		},
		save: function () { return null; }
	} );
} )( window.wp.blocks, window.wp.element, window.wp.components, window.wp.blockEditor );
