=== ACHplug — Bank payments for businesses and nonprofits, one-time and recurring ===
Contributors: achplug
Tags: ach, bank payments, recurring, invoices, no fees, donations
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

For businesses and nonprofits: one-time and recurring bank payments on your own site. Your customer approves; your own bank collects. No processor, no percentage, nobody who can hold your money.

== Description ==

**Card processors take 3% and can freeze your payout. Your own bank can collect an ACH payment for cents, and nobody can hold it.**

ACHplug puts a checkout box on any page. Card price and bank price side by side, with a discount you set — 0 to 90%. The customer presses *Pay from my bank*, enters their routing and account number (their bank's name appears as they type, checked against the Federal Reserve directory), approves in one sentence, presses *Buy*. Under two minutes, on your page.

Then it's your turn, one minute a day: open **Collect**, download one bank file, upload it on your bank's ACH origination page, press *I uploaded it*. When the money shows in your account, press *Received* — the customer gets their receipt.

**Good for business:** deposits, contracts paid off in installments, monthly service. **Good for nonprofits:** one-time gifts and monthly giving, with the tax receipt built in. Anywhere 3% is real money.

**What you get**

* **The checkout box** — drag it in with the ACHplug block or use the `[achplug]` shortcode. Takes your theme's fonts and colours.
* **Recurring payments** — a contract paid off in 12 payments, a monthly service, a yearly membership. The customer approves once; each payment appears on Collect when due; every email carries their Pause / Stop link. Nothing is collected they did not approve.
* **Collect** — approved payments in one list, one bank file, Received / Returned.
* **Sales Journal — ACH payments** — last 7 days, month, year, all time; card fees you did not pay; Unpaid / Paid / All; search; CSV.
* **Two customer emails, your wording** — the confirmation with their authorization record, and the receipt.
* **Donation mode** — the donor picks the amount; the receipt carries your EIN and the IRS acknowledgment line.
* **Encryption** — customers' account numbers are encrypted with a key that never leaves your site; you see the last four digits. The full number appears only inside the bank file, and is deleted when a customer revokes.
* **Nothing leaves your site.** No outside server holds your orders or your customers' details.

Setting up ACH origination with your bank is one phone call — the words to use, step by step: https://achplug.com/help-collect.html

== Installation ==

1. Plugins → Add New → Upload Plugin → the zip → Activate. You land on Getting started.
2. ACHplug → Settings: your payee name and address, your discount, whether customers may repeat. Section 6: your Company ID (EIN) and the routing number your bank uses for origination.
3. Edit any page, press +, search "ACHplug", drag the block in, set the name and price. Publish.

== Frequently Asked Questions ==

= Does money move through ACHplug? =
No. Your bank collects it from a file you upload. ACHplug never touches the money and cannot hold it.

= Is it safe to collect customers' account numbers? =
They are encrypted the moment they arrive, with a key kept only on your site. Your dashboard shows the last four digits. Banks, landlords and utilities collect this way every day; the customer's protection is the written authorization ACHplug records for every payment.

= What does my bank need? =
ACH origination on your business account — most banks offer it. They will give you a Company ID and the routing number to put in the file. https://achplug.com/help-collect.html has the exact words to ask.

= What if a payment bounces? =
Your bank tells you within a couple of days. Press Returned; the customer is emailed that it did not go through and is still owed.

= Can the customer stop a repeating payment? =
Yes, from the link in every email — a Revoke button, no login. You are told by email.

== Changelog ==

= 2.0.0 =
* The customer enters their bank details and approves; your bank collects (pull). Push mode kept as a setting.
* Recurring payments: weekly / monthly / yearly; until stopped, N payments, or a date. Revoke link for the customer.
* Collect page with the bank file (NACHA PPD). Daily reminder email.
* Encryption of customers' account numbers. Federal Reserve directory check on routing numbers.
* Dashboard, Sales Journal with week/month/year totals, Features page with comparison.
* Donation mode with tax-ID receipts. Box wording editable.

= 1.2.0 =
* Header on every screen; Features page.

= 1.0.0 =
* First release.
