=== ACHplug — Pay from your bank, discount you set ===
Contributors: achplug
Tags: ach, bank transfer, checkout, payments, donations, discount, no fees
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Let customers pay you straight from their bank with a discount you set. Money lands in your account, no processor in the middle. Every payment in a Sales Journal.

== Description ==

**Card processors take 3% and can freeze your money. A bank transfer costs you nothing and nobody can hold it.**

ACHplug puts a checkout box on any page. It shows two prices side by side: the card price, and the bank price with your discount already worked out — 0%, 2%, 5%, 30%, whatever you decide. A customer who picks the bank gets a clean slip with your payee name, routing number, account number and an order reference, Copy buttons, and four plain steps for their banking app. They press *I've sent it*. You get an email. When the money lands, you press *Mark received* and the customer gets their receipt.

**What you get**

* **The checkout box** — drag it into any page with the ACHplug block, or use the `[achplug]` shortcode. It takes your theme's fonts and colours.
* **Waiting for money** — a screen showing only the orders that still need a transfer to land, each with a Mark received button.
* **Sales Journal — ACH payments** — every payment your site has taken: received all time, awaiting, the card fees you did not pay, filtered by Unpaid / Paid / All, searchable, CSV download for your accountant.
* **Getting started** — three numbered steps, a sample journal, and the answers to the questions everybody asks.
* **Optional card button** linking to any checkout you already have (Stripe Payment Link, PayPal, anything).
* **Nothing leaves your site.** Orders live in your own WordPress database. No customer bank details are ever collected — the customer pays you; you never pull from them.

Built by a roofer who got tired of paying 3% on deposits. Works for contractors, consultants, nonprofits, publishers — anyone who can wait a day or two to save the fee.

**ACHplug Premium** ($50) adds editing the wording inside the box itself — the labels, the four steps, the explanation.

== Installation ==

1. Plugins → Add New → Upload Plugin → choose the zip → Install → Activate. You land on Getting started.
2. ACHplug → Settings: payee name, routing number, account number, discount. Save.
3. Edit any page, press +, search "ACHplug", drag the block in, set the name and price. Publish.

== Frequently Asked Questions ==

= Is it safe to show my routing and account number? =
It is the same information printed on every check you have ever written. It lets people pay you, not take from you. If your bank offers a receiving-only account, use that one.

= How long does a transfer take? =
Usually one to three business days. The customer is told this in the box and in their email, and nothing is released until you mark it received.

= Why offer a discount? =
You are saving the card fee and the risk of a frozen account; passing part of that on is what makes a customer choose the slower option. Set it to 0 if you would rather not.

= Does it work for donations? =
Yes — set a suggested amount as the price, or use the one-line hosted version at achplug.com which has a full donation mode with tax-ID receipts.

= What about a customer who never sends the money? =
The order sits under Waiting for money until you cancel it. Nothing was delivered, so nothing was lost.

== Screenshots ==

1. The checkout box on a page — card price and bank price side by side.
2. The bank slip with Copy buttons and the order reference.
3. Waiting for money — orders that still need a transfer, with Mark received.
4. Sales Journal — ACH payments, with totals and the Unpaid / Paid / All tabs.
5. Settings — where the money goes and the discount.
6. The ACHplug block in the editor.

== Changelog ==

= 1.2.0 =
* A header on every ACHplug screen with a Features button.
* Features page: Basic and Premium side by side, upgrade for the difference.
* Premium key in Settings unlocks Box wording — every word your customer sees inside the box.

= 1.1.0 =
* Sales Journal — ACH payments, with totals, filters, search and CSV.
* Drag-and-drop ACHplug block for the editor.
* Getting started page with numbered steps and a sample journal.
* Orders screen renamed Waiting for money and shows only unpaid orders.

= 1.0.0 =
* First release.
