/* ACHplug 1.0.0 */
(function(){
  function money(n){return '$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});}
  document.querySelectorAll('.achplug').forEach(function(box){
    var ref=null, err=box.querySelector('.achplug-err');
    function show(n){box.querySelectorAll('.achplug-screen').forEach(function(s){s.classList.toggle('is-on',s.dataset.screen==String(n));});box.scrollIntoView({block:'start',behavior:'smooth'});}
    function setRef(r){ref=r;box.querySelectorAll('.achplug-ref').forEach(function(e){e.textContent=r;});}
    // a provisional reference so the memo line is never blank; replaced by the server's
    setRef((box.dataset.sku||'REF').replace(/[^A-Z0-9]/gi,'').slice(0,3).toUpperCase()+'-'+String(Math.floor(100000+Math.random()*900000)));
    box.addEventListener('click',function(e){
      var t=e.target.closest('[data-go],[data-copy],[data-copy-ref]'); if(!t) return;
      if(t.hasAttribute('data-copy')||t.hasAttribute('data-copy-ref')){
        var txt=t.hasAttribute('data-copy-ref')?ref:t.getAttribute('data-copy');
        if(navigator.clipboard) navigator.clipboard.writeText(txt);
        t.classList.add('is-done'); t.textContent='Copied'; setTimeout(function(){t.classList.remove('is-done');t.textContent='Copy';},1500); return;
      }
      var go=t.getAttribute('data-go');
      if(go==='3'){ submit(t); return; }
      show(go);
    });
    function submit(btn){
      var name=box.querySelector('input[name=name]').value.trim(), email=box.querySelector('input[name=email]').value.trim();
      err.hidden=true;
      if(!name||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){err.textContent='Please give your name and a working email address.';err.hidden=false;return;}
      btn.disabled=true; btn.textContent='Saving…';
      fetch(ACHPLUG.rest,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':ACHPLUG.nonce},
        body:JSON.stringify({name:name,email:email,product:box.dataset.name,sku:box.dataset.sku,amount:box.dataset.ach,ref:ref})})
      .then(function(r){return r.json().then(function(j){return {ok:r.ok,j:j};});})
      .then(function(x){
        btn.disabled=false; btn.textContent="I've sent it";
        if(!x.ok){err.textContent=(x.j&&x.j.message)||'Something went wrong. Try again.';err.hidden=false;return;}
        setRef(x.j.ref); show(3);
      })
      .catch(function(){btn.disabled=false;btn.textContent="I've sent it";err.textContent='Could not reach the site. Try again.';err.hidden=false;});
    }
  });
})();
