=== ACHplug — Pay from your bank, 5% off ===
Contributors: achplug
Tags: ach, bank transfer, checkout, discount, payments
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Offer your customers a discount for paying straight from their bank instead of a card. The money goes to your account. No processor in the middle.

== Description ==

Card processors take 3% and can freeze your money. A bank transfer costs you nothing and nobody can hold it.

ACHplug puts a checkout box on any page. It shows two prices side by side: the card price, and the bank price with your discount already worked out. A customer who picks the bank gets a clean slip — your payee name, routing number, account number and an order reference — with Copy buttons, and four plain steps for their banking app. They press "I've sent it," you get an email, and the order sits in your dashboard until the transfer lands. Mark it paid, and the customer is emailed whatever link you give them.

* The box takes its font and colours from your theme. Four CSS variables if you want to adjust it.
* Optional card button linking to any checkout you already have (Stripe Payment Link, PayPal, anything).
* No customer bank details are ever collected. The customer pays you; you never pull from them.
* Nothing is sent to any outside server. Orders live in your own WordPress database.

== Installation ==

1. Upload the zip under Plugins → Add New → Upload, and activate it.
2. Go to ACHplug → Settings. Enter the payee name, routing and account numbers, and your email.
3. Put `[achplug name="What you sell" price="20"]` on any page.

== Frequently Asked Questions ==

= Is it safe to show my routing and account number? =
It is the same information printed on every cheque you have ever written. It lets people pay you, not take from you. If your bank offers a receiving-only or "deposit only" account, use that one.

= Why a discount? =
Because you are saving the card fee and the risk of a frozen account, and passing part of that on is what makes a customer choose the slower option.

= What does the customer's bank need? =
Any US bank's bill pay or "send to a business" feature. The customer enters your details once.

== Changelog ==

= 1.0.0 =
First release.
