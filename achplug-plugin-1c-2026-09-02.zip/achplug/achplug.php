<?php
/**
 * Plugin Name: ACHplug — Pay from your bank, 5% off
 * Plugin URI:  https://achplug.com
 * Description: Let customers pay you straight from their bank (ACH) with a discount you set. Money lands in your account, no processor in the middle. Comes with a Sales Journal of every ACH payment.
 * Version:     1.1.0
 * Author:      ACHplug
 * Author URI:  https://achplug.com
 * License:     GPLv2 or later
 * Text Domain: achplug
 *
 * ACHplug 1.1.0 (build 1c, 2 Sep 2026) — Sales Journal, drag-and-drop block, Getting Started page
 * Shortcode:  [achplug name="One filing read" price="20" desc="Any 8-K or 10-Q read into plain English." sku="READ"]
 * Orders:     Dashboard → ACHplug. Mark an order paid when the transfer lands; the customer is emailed.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ACHPLUG_VER', '1.1.0' );
define( 'ACHPLUG_DIR', plugin_dir_path( __FILE__ ) );
define( 'ACHPLUG_URL', plugin_dir_url( __FILE__ ) );

/* ------------------------------------------------------------------
 * Settings
 * ----------------------------------------------------------------*/
function achplug_defaults() {
	return array(
		'entity'    => '',
		'bank'      => '',
		'routing'   => '',
		'account'   => '',
		'discount'  => '5',
		'prefix'    => strtoupper( substr( preg_replace( '/[^a-z0-9]/i', '', get_bloginfo( 'name' ) ), 0, 2 ) ),
		'email'     => get_option( 'admin_email' ),
		'phone'     => '',
		'days'      => '1 to 3 business days',
		'explain'   => 'You send the money straight from your bank account to ours, the same way you pay a utility bill. No card company sits in the middle taking a cut, which is why it costs less. We unlock your purchase the moment it arrives.',
		'unlock'    => "Your transfer has arrived. Thank you.\n\nWhat you bought: {product}\nReference: {ref}\n\n{link}",
		'card_url'  => '',
		'card_label'=> 'Pay by card',
		'card_note' => 'Instant. Visa, Mastercard, Amex.',
	);
}
function achplug_opt( $k ) {
	$o = wp_parse_args( (array) get_option( 'achplug_settings', array() ), achplug_defaults() );
	return isset( $o[ $k ] ) ? $o[ $k ] : '';
}

add_action( 'admin_init', function () {
	register_setting( 'achplug', 'achplug_settings', array(
		'sanitize_callback' => function ( $in ) {
			$out = array();
			foreach ( achplug_defaults() as $k => $d ) {
				$v = isset( $in[ $k ] ) ? $in[ $k ] : $d;
				$out[ $k ] = in_array( $k, array( 'explain', 'unlock' ), true ) ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
			}
			$out['discount'] = max( 0, min( 90, (float) $out['discount'] ) );
			$out['card_url'] = esc_url_raw( $out['card_url'] );
			return $out;
		},
	) );
} );

register_activation_hook( __FILE__, function () { add_option( 'achplug_go_start', 1 ); } );
add_action( 'admin_init', function () { if ( get_option( 'achplug_go_start' ) && ! wp_doing_ajax() && current_user_can( 'manage_options' ) ) { delete_option( 'achplug_go_start' ); wp_safe_redirect( admin_url( 'admin.php?page=achplug-start' ) ); exit; } } );

/* ------------------------------------------------------------------
 * Orders — a private post type, never shown on the front
 * ----------------------------------------------------------------*/
add_action( 'init', function () {
	register_post_type( 'achplug_order', array(
		'labels'   => array( 'name' => 'ACH orders', 'singular_name' => 'ACH order' ),
		'public'   => false, 'show_ui' => false, 'supports' => array( 'title' ),
	) );
} );

/* ------------------------------------------------------------------
 * Front: assets + shortcode
 * ----------------------------------------------------------------*/
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'achplug', ACHPLUG_URL . 'assets/achplug.css', array(), ACHPLUG_VER );
	wp_register_script( 'achplug', ACHPLUG_URL . 'assets/achplug.js', array(), ACHPLUG_VER, true );
	wp_localize_script( 'achplug', 'ACHPLUG', array(
		'rest'   => esc_url_raw( rest_url( 'achplug/v1/order' ) ),
		'nonce'  => wp_create_nonce( 'wp_rest' ),
	) );
} );

add_shortcode( 'achplug', function ( $a ) {
	$a = shortcode_atts( array( 'name' => '', 'price' => '0', 'desc' => '', 'sku' => '', 'card' => '' ), $a, 'achplug' );
	if ( ! achplug_opt( 'routing' ) || ! achplug_opt( 'account' ) ) {
		return current_user_can( 'manage_options' )
			? '<p><em>ACHplug: add your bank details under Dashboard → ACHplug → Settings and this box will appear.</em></p>' : '';
	}
	wp_enqueue_style( 'achplug' ); wp_enqueue_script( 'achplug' );
	$price = (float) $a['price'];
	$disc  = (float) achplug_opt( 'discount' );
	$ach   = round( $price * ( 1 - $disc / 100 ), 2 );
	$card  = $a['card'] ? $a['card'] : achplug_opt( 'card_url' );
	ob_start(); ?>
<div class="achplug" data-name="<?php echo esc_attr( $a['name'] ); ?>" data-price="<?php echo esc_attr( $price ); ?>" data-ach="<?php echo esc_attr( $ach ); ?>" data-sku="<?php echo esc_attr( $a['sku'] ); ?>">
  <div class="achplug-head">
    <h3 class="achplug-title"><?php echo esc_html( $a['name'] ); ?></h3>
    <?php if ( $a['desc'] ) : ?><p class="achplug-desc"><?php echo esc_html( $a['desc'] ); ?></p><?php endif; ?>
  </div>

  <div class="achplug-screen is-on" data-screen="1">
    <div class="achplug-choice">
      <?php if ( $card ) : ?>
      <div class="achplug-opt achplug-card">
        <small><?php echo esc_html( achplug_opt( 'card_label' ) ); ?></small>
        <div class="achplug-price"><?php echo esc_html( achplug_money( $price ) ); ?></div>
        <small><?php echo esc_html( achplug_opt( 'card_note' ) ); ?></small>
        <a class="achplug-go" href="<?php echo esc_url( $card ); ?>"><?php echo esc_html( achplug_opt( 'card_label' ) ); ?></a>
      </div>
      <?php endif; ?>
      <div class="achplug-opt achplug-bank">
        <small>Pay from your bank</small>
        <div class="achplug-price"><?php echo esc_html( achplug_money( $ach ) ); ?></div>
        <?php if ( $disc > 0 ) : ?><span class="achplug-was"><?php echo esc_html( achplug_money( $price ) ); ?></span>
        <span class="achplug-save">You save <?php echo esc_html( rtrim( rtrim( number_format( $disc, 1 ), '0' ), '.' ) ); ?>%</span><?php endif; ?>
        <button type="button" class="achplug-go" data-go="2">Pay from my bank</button>
      </div>
    </div>
    <details class="achplug-why"><summary>What is paying from my bank?</summary><p><?php echo esc_html( achplug_opt( 'explain' ) ); ?></p></details>
  </div>

  <div class="achplug-screen" data-screen="2">
    <label class="achplug-field"><span>Your name</span><input type="text" name="name" autocomplete="name" placeholder="As it appears on your bank account" required></label>
    <label class="achplug-field"><span>Email — we unlock your purchase here</span><input type="email" name="email" autocomplete="email" placeholder="you@example.com" required></label>
    <div class="achplug-slip">
      <h4>Send this from your bank</h4>
      <div class="achplug-row"><span>Amount</span><b class="achplug-big"><?php echo esc_html( achplug_money( $ach ) ); ?></b></div>
      <div class="achplug-row"><span>Pay to</span><b><?php echo esc_html( achplug_opt( 'entity' ) ); ?></b></div>
      <?php if ( achplug_opt( 'bank' ) ) : ?><div class="achplug-row"><span>Bank</span><b><?php echo esc_html( achplug_opt( 'bank' ) ); ?></b></div><?php endif; ?>
      <div class="achplug-row"><span>Routing number</span><b><?php echo esc_html( achplug_opt( 'routing' ) ); ?> <button type="button" class="achplug-copy" data-copy="<?php echo esc_attr( achplug_opt( 'routing' ) ); ?>">Copy</button></b></div>
      <div class="achplug-row"><span>Account number</span><b><?php echo esc_html( achplug_opt( 'account' ) ); ?> <button type="button" class="achplug-copy" data-copy="<?php echo esc_attr( achplug_opt( 'account' ) ); ?>">Copy</button></b></div>
      <div class="achplug-row"><span>Memo / reference</span><b><span class="achplug-ref">—</span> <button type="button" class="achplug-copy" data-copy-ref>Copy</button></b></div>
    </div>
    <ol class="achplug-steps">
      <li>Open your bank's app or website.</li>
      <li>Choose <em>Pay a bill</em> or <em>Send money to a business</em> and add us using the details above.</li>
      <li>Put the reference in the memo so we can match it to you.</li>
      <li>Send the amount, then come back and press the button below.</li>
    </ol>
    <p class="achplug-err" hidden></p>
    <button type="button" class="achplug-primary" data-go="3">I've sent it</button>
    <button type="button" class="achplug-ghost" data-go="1">Back</button>
  </div>

  <div class="achplug-screen" data-screen="3">
    <div class="achplug-done">
      <div class="achplug-mark">✓</div>
      <h4>Thank you. We're watching for it.</h4>
      <div class="achplug-ord achplug-ref">—</div>
      <p>Keep this reference. When your transfer lands — usually <?php echo esc_html( achplug_opt( 'days' ) ); ?> — we'll email your purchase to the address you gave. Nothing else to do.</p>
    </div>
  </div>

  <div class="achplug-foot">
    <span>Questions? <b><?php echo esc_html( achplug_opt( 'email' ) ); ?></b><?php if ( achplug_opt( 'phone' ) ) : ?> · <b><?php echo esc_html( achplug_opt( 'phone' ) ); ?></b><?php endif; ?></span>
    <span>Pay-from-bank checkout by <a href="https://achplug.com" rel="noopener">ACHplug</a></span>
  </div>
</div>
<?php
	return ob_get_clean();
} );

function achplug_money( $n ) { return '$' . number_format( (float) $n, 2 ); }

/* ------------------------------------------------------------------
 * REST: the customer says "I've sent it" → an order is written
 * ----------------------------------------------------------------*/
add_action( 'rest_api_init', function () {
	register_rest_route( 'achplug/v1', '/order', array(
		'methods'  => 'POST',
		'permission_callback' => '__return_true',
		'callback' => function ( WP_REST_Request $r ) {
			if ( ! wp_verify_nonce( $r->get_header( 'x-wp-nonce' ), 'wp_rest' ) ) {
				return new WP_Error( 'bad_nonce', 'Please reload the page and try again.', array( 'status' => 403 ) );
			}
			$name  = sanitize_text_field( $r['name'] );
			$email = sanitize_email( $r['email'] );
			$prod  = sanitize_text_field( $r['product'] );
			$sku   = sanitize_text_field( $r['sku'] );
			$amt   = round( (float) $r['amount'], 2 );
			if ( ! $name || ! is_email( $email ) || ! $prod || $amt <= 0 ) {
				return new WP_Error( 'missing', 'Please give your name and a working email address.', array( 'status' => 400 ) );
			}
			// simple flood control: 5 orders per IP per hour
			$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '0';
			$key = 'achplug_ip_' . md5( $ip );
			$n   = (int) get_transient( $key );
			if ( $n >= 5 ) return new WP_Error( 'slow', 'Too many orders from this connection. Try again in an hour.', array( 'status' => 429 ) );
			set_transient( $key, $n + 1, HOUR_IN_SECONDS );

			$ref = achplug_opt( 'prefix' ) . '-' . str_pad( wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );
			$id  = wp_insert_post( array(
				'post_type' => 'achplug_order', 'post_status' => 'private', 'post_title' => $ref,
				'meta_input' => array(
					'name' => $name, 'email' => $email, 'product' => $prod, 'sku' => $sku,
					'amount' => $amt, 'status' => 'awaiting', 'ip' => $ip,
				),
			) );
			if ( ! $id ) return new WP_Error( 'save', 'Could not save the order. Try again.', array( 'status' => 500 ) );

			$to = achplug_opt( 'email' );
			if ( $to ) wp_mail( $to, "ACH order $ref — " . achplug_money( $amt ),
				"$name <$email> says a transfer of " . achplug_money( $amt ) . " is on its way.\nProduct: $prod\nReference: $ref\n\nMark it paid when it lands: " . admin_url( 'admin.php?page=achplug' ) );
			return array( 'ref' => $ref );
		},
	) );
} );

/* ------------------------------------------------------------------
 * Admin: the desk + settings
 * ----------------------------------------------------------------*/
add_action( 'admin_menu', function () {
	$waiting = count( get_posts( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'meta_key' => 'status', 'meta_value' => 'awaiting', 'fields' => 'ids', 'numberposts' => 99 ) ) );
	$badge   = $waiting ? " <span class='update-plugins count-$waiting'><span class='plugin-count'>$waiting</span></span>" : '';
	add_menu_page( 'ACHplug', 'ACHplug' . $badge, 'manage_options', 'achplug', 'achplug_desk', 'dashicons-bank', 58 );
	add_submenu_page( 'achplug', 'Waiting for money', 'Waiting for money', 'manage_options', 'achplug', 'achplug_desk' );
	add_submenu_page( 'achplug', 'Sales Journal — ACH payments', 'Sales Journal', 'manage_options', 'achplug-journal', 'achplug_journal_page' );
	add_submenu_page( 'achplug', 'Settings', 'Settings', 'manage_options', 'achplug-settings', 'achplug_settings_page' );
	add_submenu_page( 'achplug', 'Getting started', 'Getting started', 'manage_options', 'achplug-start', 'achplug_start_page' );
} );

add_action( 'admin_post_achplug_mark', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'achplug_mark' ) ) wp_die( 'No.' );
	$id = (int) $_POST['id']; $to = sanitize_key( $_POST['to'] );
	if ( get_post_type( $id ) === 'achplug_order' && in_array( $to, array( 'paid', 'awaiting', 'cancelled' ), true ) ) {
		update_post_meta( $id, 'status', $to );
		if ( $to === 'paid' ) {
			update_post_meta( $id, 'paid_at', current_time( 'mysql' ) );
			$link = isset( $_POST['link'] ) ? esc_url_raw( $_POST['link'] ) : '';
			if ( $link ) update_post_meta( $id, 'link', $link );
			$body = strtr( achplug_opt( 'unlock' ), array(
				'{product}' => get_post_meta( $id, 'product', true ),
				'{ref}'     => get_the_title( $id ),
				'{link}'    => $link,
				'{name}'    => get_post_meta( $id, 'name', true ),
			) );
			wp_mail( get_post_meta( $id, 'email', true ), 'Your ' . get_bloginfo( 'name' ) . ' purchase — ' . get_the_title( $id ), $body );
		}
	}
	wp_safe_redirect( admin_url( 'admin.php?page=achplug' ) ); exit;
} );

function achplug_desk() {
	$orders = get_posts( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'numberposts' => 200, 'orderby' => 'date', 'order' => 'DESC', 'meta_key' => 'status', 'meta_value' => 'awaiting' ) );
	echo '<div class="wrap"><h1>Waiting for money</h1>';
	echo '<p>Only orders that still need a transfer to land are shown here. When the money is in your bank, press <strong>Mark received</strong> — the customer is emailed, and the order moves to the <a href="' . esc_url( admin_url( 'admin.php?page=achplug-journal' ) ) . '">Sales Journal</a>.</p>';
	if ( ! $orders ) { echo '<p><strong>Nothing waiting.</strong> When a customer presses <em>I\'ve sent it</em>, it appears here and you get an email. New here? See <a href="' . esc_url( admin_url( 'admin.php?page=achplug-start' ) ) . '">Getting started</a>.</p></div>'; return; }
	echo '<table class="widefat striped"><thead><tr><th>Reference</th><th>When</th><th>Customer</th><th>Product</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>';
	foreach ( $orders as $o ) {
		$s = get_post_meta( $o->ID, 'status', true );
		$style = $s === 'paid' ? 'color:#1E6B4E;font-weight:600' : ( $s === 'cancelled' ? 'color:#888' : 'color:#b45309;font-weight:600' );
		echo '<tr><td><code>' . esc_html( $o->post_title ) . '</code></td><td>' . esc_html( get_date_from_gmt( $o->post_date_gmt, 'j M Y, g:ia' ) ) . '</td>';
		echo '<td>' . esc_html( get_post_meta( $o->ID, 'name', true ) ) . '<br><a href="mailto:' . esc_attr( get_post_meta( $o->ID, 'email', true ) ) . '">' . esc_html( get_post_meta( $o->ID, 'email', true ) ) . '</a></td>';
		echo '<td>' . esc_html( get_post_meta( $o->ID, 'product', true ) ) . '</td><td>' . esc_html( achplug_money( get_post_meta( $o->ID, 'amount', true ) ) ) . '</td>';
		echo '<td style="' . $style . '">' . esc_html( ucfirst( $s ) ) . '</td><td>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:4px;flex-wrap:wrap">';
		wp_nonce_field( 'achplug_mark' );
		echo '<input type="hidden" name="action" value="achplug_mark"><input type="hidden" name="id" value="' . (int) $o->ID . '">';
		if ( $s !== 'paid' ) {
			echo '<input type="url" name="link" placeholder="Download or access link (optional)" style="width:220px">';
			echo '<button class="button button-primary" name="to" value="paid">Mark received &amp; email</button>';
			echo '<button class="button" name="to" value="cancelled">Cancel</button>';
		} else {
			echo '<button class="button" name="to" value="awaiting">Undo</button>';
		}
		echo '</form></td></tr>';
	}
	echo '</tbody></table></div>';
}

/* ------------------------------------------------------------------
 * Sales Journal — every ACH payment, filtered, with totals and CSV
 * ----------------------------------------------------------------*/
function achplug_journal_rows() {
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'achplug_order', 'post_status' => 'private', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'DESC' ) ) as $o ) {
		$out[] = array( 'id' => $o->ID, 'ref' => $o->post_title, 'created' => get_date_from_gmt( $o->post_date_gmt, 'Y-m-d' ), 'paid_at' => substr( (string) get_post_meta( $o->ID, 'paid_at', true ), 0, 10 ),
			'status' => get_post_meta( $o->ID, 'status', true ), 'name' => get_post_meta( $o->ID, 'name', true ), 'email' => get_post_meta( $o->ID, 'email', true ),
			'product' => get_post_meta( $o->ID, 'product', true ), 'amount' => (float) get_post_meta( $o->ID, 'amount', true ) );
	}
	return $out;
}
add_action( 'admin_init', function () {
	if ( isset( $_GET['page'], $_GET['achplug_csv'] ) && $_GET['page'] === 'achplug-journal' && current_user_can( 'manage_options' ) ) {
		header( 'Content-Type: text/csv' ); header( 'Content-Disposition: attachment; filename="sales-journal-ach-' . date( 'Y-m-d' ) . '.csv"' );
		$f = fopen( 'php://output', 'w' ); fputcsv( $f, array( 'Reference', 'Date created', 'Date received', 'Status', 'Customer', 'Email', 'Product', 'Amount' ) );
		foreach ( achplug_journal_rows() as $r ) fputcsv( $f, array( $r['ref'], $r['created'], $r['paid_at'], $r['status'], $r['name'], $r['email'], $r['product'], number_format( $r['amount'], 2, '.', '' ) ) );
		exit;
	}
} );
function achplug_journal_page() {
	$all = achplug_journal_rows(); $v = isset( $_GET['v'] ) ? sanitize_key( $_GET['v'] ) : 'unpaid'; $q = isset( $_GET['q'] ) ? strtolower( sanitize_text_field( $_GET['q'] ) ) : '';
	$paid = array_filter( $all, fn( $r ) => $r['status'] === 'paid' ); $wait = array_filter( $all, fn( $r ) => $r['status'] === 'awaiting' );
	$sum = fn( $a ) => array_sum( array_map( fn( $r ) => $r['amount'], $a ) );
	$shown = array_filter( $all, fn( $r ) => ( $v === 'all' || ( $v === 'paid' ? $r['status'] === 'paid' : $r['status'] !== 'paid' ) ) && ( ! $q || strpos( strtolower( $r['ref'] . ' ' . $r['name'] . ' ' . $r['email'] . ' ' . $r['product'] ), $q ) !== false ) );
	$fees = array_sum( array_map( fn( $r ) => $r['amount'] * 0.029 + 0.30, $paid ) );
	$base = admin_url( 'admin.php?page=achplug-journal' );
	$tab = fn( $k, $l ) => '<a class="achplug-tab' . ( $v === $k ? ' current' : '' ) . '" href="' . esc_url( add_query_arg( array( 'v' => $k, 'q' => $q ), $base ) ) . '">' . $l . '</a>';
	echo '<div class="wrap"><h1>Sales Journal — ACH payments</h1>';
	echo '<p>Every ACH payment your site has taken. <a href="' . esc_url( add_query_arg( 'achplug_csv', 1, $base ) ) . '">Download CSV</a> for your accountant.</p>';
	echo '<style>.achplug-cards{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}.achplug-cards div{background:#fff;border:1px solid #ccd;border-radius:8px;padding:12px 16px;min-width:180px}.achplug-cards b{display:block;font-size:24px}.achplug-cards small{color:#666}.achplug-tab{display:inline-block;padding:5px 12px;border:1px solid #ccd;border-radius:16px;margin-right:6px;text-decoration:none;background:#fff}.achplug-tab.current{background:#1d2327;color:#fff;border-color:#1d2327}</style>';
	echo '<div class="achplug-cards"><div><small>Received, all time</small><b>' . esc_html( achplug_money( $sum( $paid ) ) ) . '</b><small>' . count( $paid ) . ' payments</small></div><div><small>Awaiting transfer</small><b>' . esc_html( achplug_money( $sum( $wait ) ) ) . '</b><small>' . count( $wait ) . ' orders</small></div><div><small>Card fees you did not pay</small><b>' . esc_html( achplug_money( $fees ) ) . '</b><small>at 2.9% + 30¢</small></div></div>';
	echo '<form method="get" style="margin:10px 0"><input type="hidden" name="page" value="achplug-journal"><input type="hidden" name="v" value="' . esc_attr( $v ) . '">' . $tab( 'unpaid', 'Unpaid (' . count( array_filter( $all, fn( $r ) => $r['status'] !== 'paid' ) ) . ')' ) . $tab( 'paid', 'Paid (' . count( $paid ) . ')' ) . $tab( 'all', 'All (' . count( $all ) . ')' ) . ' <input name="q" value="' . esc_attr( $q ) . '" placeholder="Search name, email, reference, product"> <button class="button">Search</button></form>';
	echo '<table class="widefat striped"><thead><tr><th>Reference</th><th>Date created</th><th>Date received</th><th>Status</th><th>Customer</th><th>Product</th><th>Amount</th><th>Action</th></tr></thead><tbody>';
	if ( ! $shown ) echo '<tr><td colspan="8">Nothing here yet.</td></tr>';
	foreach ( $shown as $r ) {
		$style = $r['status'] === 'paid' ? 'color:#1E6B4E;font-weight:600' : ( $r['status'] === 'cancelled' ? 'color:#888' : 'color:#b45309;font-weight:600' );
		echo '<tr><td><code>' . esc_html( $r['ref'] ) . '</code></td><td>' . esc_html( $r['created'] ) . '</td><td>' . esc_html( $r['paid_at'] ) . '</td><td style="' . $style . '">' . esc_html( ucfirst( $r['status'] ) ) . '</td><td>' . esc_html( $r['name'] ) . '<br><a href="mailto:' . esc_attr( $r['email'] ) . '">' . esc_html( $r['email'] ) . '</a></td><td>' . esc_html( $r['product'] ) . '</td><td>' . esc_html( achplug_money( $r['amount'] ) ) . '</td><td>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( 'achplug_mark' ); echo '<input type="hidden" name="action" value="achplug_mark"><input type="hidden" name="id" value="' . (int) $r['id'] . '">';
		echo $r['status'] !== 'paid' ? '<button class="button button-primary button-small" name="to" value="paid">Mark received</button> <button class="button button-small" name="to" value="cancelled">Cancel</button>' : '<button class="button button-small" name="to" value="awaiting">Undo</button>';
		echo '</form></td></tr>';
	}
	echo '</tbody></table></div>';
}

/* ------------------------------------------------------------------
 * Getting started — numbered steps, a sample journal, the block
 * ----------------------------------------------------------------*/
function achplug_start_page() {
	$ready = achplug_opt( 'routing' ) && achplug_opt( 'account' ) && achplug_opt( 'entity' ); ?>
	<div class="wrap"><h1>Getting started with ACHplug</h1>
	<style>.achplug-steps{counter-reset:s;list-style:none;margin:0;padding:0;max-width:760px}.achplug-steps li{counter-increment:s;background:#fff;border:1px solid #ccd;border-radius:8px;padding:14px 16px 14px 56px;position:relative;margin:10px 0;font-size:14px}.achplug-steps li::before{content:counter(s);position:absolute;left:14px;top:12px;width:28px;height:28px;border-radius:50%;background:#1E6B4E;color:#fff;font-weight:600;display:flex;align-items:center;justify-content:center}.achplug-steps b{display:block;margin-bottom:2px;font-size:15px}.achplug-done{color:#1E6B4E;font-weight:600}</style>
	<p style="font-size:15px;max-width:70ch">ACHplug puts a box on your site that lets a customer pay you straight from their bank, with a discount you set. Nothing to configure beyond your own bank details. Three steps:</p>
	<ol class="achplug-steps">
		<li><b>Enter where the money goes <?php if ( $ready ) echo '<span class="achplug-done">— done</span>'; ?></b><a href="<?php echo esc_url( admin_url( 'admin.php?page=achplug-settings' ) ); ?>">ACHplug → Settings</a>: your payee name exactly as the bank has it, routing number, account number, and the discount you want to give (0 for none). Save.</li>
		<li><b>Put the box on a page</b>Open any page or post in the editor, press the <strong>+</strong> button, and search for <strong>ACHplug</strong>. Drag the block in, type what you sell and the price in the panel on the right. Or, if you prefer, paste the shortcode: <code>[achplug name="What you sell" price="20"]</code></li>
		<li><b>Wait for the money, then mark it received</b>When a customer pays, you get an email and the order appears under <a href="<?php echo esc_url( admin_url( 'admin.php?page=achplug' ) ); ?>">Waiting for money</a>. When the transfer lands in your bank, press <strong>Mark received</strong>. The customer is emailed their receipt and the order moves to the Sales Journal.</li>
	</ol>
	<h2>What the Sales Journal looks like</h2>
	<p>Every ACH payment your site takes, with a running total. This is a sample:</p>
	<table class="widefat striped" style="max-width:900px"><thead><tr><th>Reference</th><th>Date created</th><th>Date received</th><th>Status</th><th>Customer</th><th>Product</th><th>Amount</th></tr></thead><tbody>
	<tr><td><code>JC-482913</code></td><td>2026-09-02</td><td></td><td style="color:#b45309;font-weight:600">Awaiting</td><td>Maria Lopez</td><td>One filing read</td><td>$19.00</td></tr>
	<tr><td><code>JC-118204</code></td><td>2026-09-01</td><td></td><td style="color:#b45309;font-weight:600">Awaiting</td><td>Tom Reilly</td><td>Roof inspection deposit</td><td>$475.00</td></tr>
	<tr><td><code>JC-771530</code></td><td>2026-08-30</td><td>2026-09-01</td><td style="color:#1E6B4E;font-weight:600">Paid</td><td>D. Nguyen</td><td>Annual membership</td><td>$57.00</td></tr>
	<tr><td><code>JC-204871</code></td><td>2026-08-28</td><td>2026-08-30</td><td style="color:#1E6B4E;font-weight:600">Paid</td><td>Sal Ferraro</td><td>Roof inspection deposit</td><td>$475.00</td></tr>
	</tbody></table>
	<p>Filter it by Unpaid, Paid or All, search it, and download it as a CSV for your accountant. <a href="<?php echo esc_url( admin_url( 'admin.php?page=achplug-journal' ) ); ?>">Open your Sales Journal →</a></p>
	<h2>Questions</h2>
	<p><strong>Is it safe to show my routing and account number?</strong> It is the same information printed on every check you have ever written. It lets people pay you, not take from you. If your bank offers a receiving-only account, use that one.</p>
	<p><strong>How long does a transfer take?</strong> Usually one to three business days. The customer is told this in the box and in their email.</p>
	<p><strong>Can I change the wording?</strong> The two customer emails, yes, in Settings. The wording inside the box itself is part of ACHplug Premium.</p>
	<p>Help: <a href="mailto:realroofers@gmail.com">realroofers@gmail.com</a> · <a href="https://achplug.com/features.html">achplug.com/features</a></p>
	</div>
<?php }

/* ------------------------------------------------------------------
 * Block — drag-and-drop in the editor; renders the shortcode
 * ----------------------------------------------------------------*/
add_action( 'init', function () {
	wp_register_script( 'achplug-block', ACHPLUG_URL . 'assets/block.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor' ), ACHPLUG_VER, true );
	register_block_type( 'achplug/box', array(
		'editor_script'   => 'achplug-block',
		'attributes'      => array( 'name' => array( 'type' => 'string', 'default' => 'What you sell' ), 'price' => array( 'type' => 'string', 'default' => '20' ), 'desc' => array( 'type' => 'string', 'default' => '' ), 'sku' => array( 'type' => 'string', 'default' => '' ) ),
		'render_callback' => function ( $a ) { return do_shortcode( sprintf( '[achplug name="%s" price="%s" desc="%s" sku="%s"]', esc_attr( $a['name'] ), esc_attr( $a['price'] ), esc_attr( $a['desc'] ), esc_attr( $a['sku'] ) ) ); },
	) );
} );

function achplug_settings_page() {
	$o = wp_parse_args( (array) get_option( 'achplug_settings', array() ), achplug_defaults() );
	$f = function ( $k, $label, $help = '', $type = 'text' ) use ( $o ) {
		echo '<tr><th scope="row"><label for="ap_' . $k . '">' . esc_html( $label ) . '</label></th><td>';
		if ( $type === 'textarea' ) echo '<textarea id="ap_' . $k . '" name="achplug_settings[' . $k . ']" rows="4" class="large-text">' . esc_textarea( $o[ $k ] ) . '</textarea>';
		else echo '<input id="ap_' . $k . '" type="' . $type . '" name="achplug_settings[' . $k . ']" value="' . esc_attr( $o[ $k ] ) . '" class="regular-text">';
		if ( $help ) echo '<p class="description">' . esc_html( $help ) . '</p>';
		echo '</td></tr>';
	}; ?>
	<div class="wrap"><h1>ACHplug settings</h1>
	<form method="post" action="options.php"><?php settings_fields( 'achplug' ); ?>
	<h2>Where the money goes</h2><table class="form-table">
	<?php $f( 'entity', 'Pay to (legal name)', 'Exactly as the bank has it. This is what the customer types as the payee.' );
	$f( 'bank', 'Bank name' );
	$f( 'routing', 'Routing number' );
	$f( 'account', 'Account number', 'Shown to customers so they can pay you. Use a receiving-only account if your bank offers one.' ); ?>
	</table>
	<h2>The offer</h2><table class="form-table">
	<?php $f( 'discount', 'Discount for paying from the bank (%)', 'Any number: 0 (no discount, both prices the same), 1, 2, 5, 30 — your call. Change it any time; every box updates.', 'number' );
	$f( 'days', 'How long it takes', 'Shown to the customer, e.g. "1 to 3 business days".' );
	$f( 'explain', 'Plain-English explanation', 'Opens under "What is paying from my bank?"', 'textarea' );
	$f( 'prefix', 'Reference prefix', 'Two or three letters. Orders look like AB-482913.' ); ?>
	</table>
	<h2>Card option (optional)</h2><table class="form-table">
	<?php $f( 'card_url', 'Card checkout link', 'A Stripe Payment Link, PayPal link or any checkout page. Leave blank to offer bank transfer only. Can also be set per box with card="…".', 'url' );
	$f( 'card_label', 'Card button says' );
	$f( 'card_note', 'Small print under the card price' ); ?>
	</table>
	<h2>Emails</h2><table class="form-table">
	<?php $f( 'email', 'Your email', 'New orders come here, and it is printed in the box for questions.', 'email' );
	$f( 'phone', 'Phone (optional)', 'Printed in the box.' );
	$f( 'unlock', 'Email sent when you mark an order paid', 'You can use {name} {product} {ref} {link}.', 'textarea' ); ?>
	</table>
	<?php submit_button( 'Save' ); ?></form>
	<h2>Use it</h2>
	<p>Put this on any page or post, changing the words and the price:</p>
	<pre><code>[achplug name="One filing read" price="20" desc="Any 8-K or 10-Q read into plain English." sku="READ"]</code></pre>
	<p>The box takes its font and colours from your theme. To adjust, add to <em>Appearance → Customize → Additional CSS</em>:</p>
	<pre><code>.achplug{ --ach-accent:#1E6B4E; --ach-bg:#F7F9F6; --ach-line:#C9D4CE; --ach-radius:10px; }</code></pre>
	</div>
<?php }
